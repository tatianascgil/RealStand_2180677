﻿namespace ProjetoStandOficina
{
    partial class FormOficina
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.Windows.Forms.Label descricaoLabel;
            System.Windows.Forms.Label valorLabel;
            this.listBoxCliente = new System.Windows.Forms.ListBox();
            this.btnICarro = new System.Windows.Forms.Button();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.listBoxCarro = new System.Windows.Forms.ListBox();
            this.listBoxServico = new System.Windows.Forms.ListBox();
            this.listBoxParcela = new System.Windows.Forms.ListBox();
            this.btnIServico = new System.Windows.Forms.Button();
            this.btnIParcela = new System.Windows.Forms.Button();
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.groupBox3 = new System.Windows.Forms.GroupBox();
            this.comboBox1 = new System.Windows.Forms.ComboBox();
            this.groupBox4 = new System.Windows.Forms.GroupBox();
            this.valorTextBox = new System.Windows.Forms.TextBox();
            this.descricaoTextBox = new System.Windows.Forms.TextBox();
            this.lbNome = new System.Windows.Forms.Label();
            this.lbNif = new System.Windows.Forms.Label();
            this.lbMorada = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.lbTotal = new System.Windows.Forms.Label();
            this.lbContacto = new System.Windows.Forms.Label();
            this.toolStrip1 = new System.Windows.Forms.ToolStrip();
            this.sairToolStripMenuItem = new System.Windows.Forms.ToolStripLabel();
            this.clienteBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.parcelasBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.servicosBindingSource = new System.Windows.Forms.BindingSource(this.components);
            descricaoLabel = new System.Windows.Forms.Label();
            valorLabel = new System.Windows.Forms.Label();
            this.groupBox1.SuspendLayout();
            this.groupBox2.SuspendLayout();
            this.groupBox3.SuspendLayout();
            this.groupBox4.SuspendLayout();
            this.toolStrip1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.clienteBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.parcelasBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.servicosBindingSource)).BeginInit();
            this.SuspendLayout();
            // 
            // descricaoLabel
            // 
            descricaoLabel.AutoSize = true;
            descricaoLabel.Location = new System.Drawing.Point(185, 79);
            descricaoLabel.Name = "descricaoLabel";
            descricaoLabel.Size = new System.Drawing.Size(58, 13);
            descricaoLabel.TabIndex = 9;
            descricaoLabel.Text = "Descricao:";
            // 
            // valorLabel
            // 
            valorLabel.AutoSize = true;
            valorLabel.Location = new System.Drawing.Point(185, 156);
            valorLabel.Name = "valorLabel";
            valorLabel.Size = new System.Drawing.Size(34, 13);
            valorLabel.TabIndex = 10;
            valorLabel.Text = "Valor:";
            // 
            // listBoxCliente
            // 
            this.listBoxCliente.FormattingEnabled = true;
            this.listBoxCliente.Location = new System.Drawing.Point(6, 19);
            this.listBoxCliente.Name = "listBoxCliente";
            this.listBoxCliente.Size = new System.Drawing.Size(185, 368);
            this.listBoxCliente.TabIndex = 0;
            this.listBoxCliente.SelectedIndexChanged += new System.EventHandler(this.listBoxCliente_SelectedIndexChanged);
            // 
            // btnICarro
            // 
            this.btnICarro.BackColor = System.Drawing.SystemColors.Desktop;
            this.btnICarro.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.btnICarro.Font = new System.Drawing.Font("Microsoft Sans Serif", 8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnICarro.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.btnICarro.Location = new System.Drawing.Point(6, 276);
            this.btnICarro.Name = "btnICarro";
            this.btnICarro.Size = new System.Drawing.Size(157, 24);
            this.btnICarro.TabIndex = 2;
            this.btnICarro.Text = "Inserir Carro";
            this.btnICarro.UseVisualStyleBackColor = false;
            this.btnICarro.Click += new System.EventHandler(this.btnICarro_Click);
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.listBoxCliente);
            this.groupBox1.Location = new System.Drawing.Point(12, 27);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(198, 400);
            this.groupBox1.TabIndex = 4;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "Seleciona um Cliente";
            // 
            // listBoxCarro
            // 
            this.listBoxCarro.FormattingEnabled = true;
            this.listBoxCarro.Location = new System.Drawing.Point(6, 19);
            this.listBoxCarro.Name = "listBoxCarro";
            this.listBoxCarro.Size = new System.Drawing.Size(157, 251);
            this.listBoxCarro.TabIndex = 5;
            this.listBoxCarro.SelectedIndexChanged += new System.EventHandler(this.listBoxCarro_SelectedIndexChanged);
            // 
            // listBoxServico
            // 
            this.listBoxServico.FormattingEnabled = true;
            this.listBoxServico.Location = new System.Drawing.Point(8, 19);
            this.listBoxServico.Name = "listBoxServico";
            this.listBoxServico.Size = new System.Drawing.Size(154, 238);
            this.listBoxServico.TabIndex = 6;
            this.listBoxServico.SelectedIndexChanged += new System.EventHandler(this.listBoxServico_SelectedIndexChanged);
            // 
            // listBoxParcela
            // 
            this.listBoxParcela.FormattingEnabled = true;
            this.listBoxParcela.Location = new System.Drawing.Point(6, 18);
            this.listBoxParcela.Name = "listBoxParcela";
            this.listBoxParcela.Size = new System.Drawing.Size(173, 277);
            this.listBoxParcela.TabIndex = 7;
            // 
            // btnIServico
            // 
            this.btnIServico.BackColor = System.Drawing.SystemColors.Desktop;
            this.btnIServico.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.btnIServico.Font = new System.Drawing.Font("Microsoft Sans Serif", 8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnIServico.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.btnIServico.Location = new System.Drawing.Point(8, 276);
            this.btnIServico.Name = "btnIServico";
            this.btnIServico.Size = new System.Drawing.Size(154, 24);
            this.btnIServico.TabIndex = 8;
            this.btnIServico.Text = "Inserir Serviço";
            this.btnIServico.UseVisualStyleBackColor = false;
            this.btnIServico.Click += new System.EventHandler(this.btnIServico_Click);
            // 
            // btnIParcela
            // 
            this.btnIParcela.BackColor = System.Drawing.SystemColors.Desktop;
            this.btnIParcela.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.btnIParcela.Font = new System.Drawing.Font("Microsoft Sans Serif", 8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnIParcela.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.btnIParcela.Location = new System.Drawing.Point(185, 271);
            this.btnIParcela.Name = "btnIParcela";
            this.btnIParcela.Size = new System.Drawing.Size(126, 24);
            this.btnIParcela.TabIndex = 9;
            this.btnIParcela.Text = "Inserir Parcela";
            this.btnIParcela.UseVisualStyleBackColor = false;
            this.btnIParcela.Click += new System.EventHandler(this.btnIParcela_Click);
            // 
            // groupBox2
            // 
            this.groupBox2.Controls.Add(this.listBoxCarro);
            this.groupBox2.Controls.Add(this.btnICarro);
            this.groupBox2.Location = new System.Drawing.Point(210, 115);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Size = new System.Drawing.Size(169, 312);
            this.groupBox2.TabIndex = 10;
            this.groupBox2.TabStop = false;
            this.groupBox2.Text = "Carro FormOficina";
            // 
            // groupBox3
            // 
            this.groupBox3.Controls.Add(this.comboBox1);
            this.groupBox3.Controls.Add(this.btnIServico);
            this.groupBox3.Controls.Add(this.listBoxServico);
            this.groupBox3.Location = new System.Drawing.Point(379, 115);
            this.groupBox3.Name = "groupBox3";
            this.groupBox3.Size = new System.Drawing.Size(174, 312);
            this.groupBox3.TabIndex = 11;
            this.groupBox3.TabStop = false;
            this.groupBox3.Text = "Serviço";
            // 
            // comboBox1
            // 
            this.comboBox1.FormattingEnabled = true;
            this.comboBox1.Items.AddRange(new object[] {
            "ARRANJO",
            "MARCAR"});
            this.comboBox1.Location = new System.Drawing.Point(8, 249);
            this.comboBox1.Name = "comboBox1";
            this.comboBox1.Size = new System.Drawing.Size(154, 21);
            this.comboBox1.TabIndex = 9;
            // 
            // groupBox4
            // 
            this.groupBox4.Controls.Add(valorLabel);
            this.groupBox4.Controls.Add(this.valorTextBox);
            this.groupBox4.Controls.Add(descricaoLabel);
            this.groupBox4.Controls.Add(this.descricaoTextBox);
            this.groupBox4.Controls.Add(this.listBoxParcela);
            this.groupBox4.Controls.Add(this.btnIParcela);
            this.groupBox4.Location = new System.Drawing.Point(547, 114);
            this.groupBox4.Name = "groupBox4";
            this.groupBox4.Size = new System.Drawing.Size(320, 313);
            this.groupBox4.TabIndex = 12;
            this.groupBox4.TabStop = false;
            this.groupBox4.Text = "Parcelas";
            // 
            // valorTextBox
            // 
            this.valorTextBox.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.parcelasBindingSource, "Valor", true));
            this.valorTextBox.Location = new System.Drawing.Point(188, 172);
            this.valorTextBox.Name = "valorTextBox";
            this.valorTextBox.Size = new System.Drawing.Size(100, 20);
            this.valorTextBox.TabIndex = 11;
            // 
            // descricaoTextBox
            // 
            this.descricaoTextBox.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.parcelasBindingSource, "Descricao", true));
            this.descricaoTextBox.Location = new System.Drawing.Point(185, 95);
            this.descricaoTextBox.Name = "descricaoTextBox";
            this.descricaoTextBox.Size = new System.Drawing.Size(100, 20);
            this.descricaoTextBox.TabIndex = 10;
            // 
            // lbNome
            // 
            this.lbNome.AutoSize = true;
            this.lbNome.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.clienteBindingSource, "Nome", true));
            this.lbNome.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbNome.Location = new System.Drawing.Point(252, 26);
            this.lbNome.Name = "lbNome";
            this.lbNome.Size = new System.Drawing.Size(210, 20);
            this.lbNome.TabIndex = 13;
            this.lbNome.Text = "Sem Cliente Selecionado";
            // 
            // lbNif
            // 
            this.lbNif.AutoSize = true;
            this.lbNif.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.clienteBindingSource, "NIF", true));
            this.lbNif.Location = new System.Drawing.Point(265, 48);
            this.lbNif.Name = "lbNif";
            this.lbNif.Size = new System.Drawing.Size(0, 13);
            this.lbNif.TabIndex = 14;
            // 
            // lbMorada
            // 
            this.lbMorada.AutoSize = true;
            this.lbMorada.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.clienteBindingSource, "Morada", true));
            this.lbMorada.Location = new System.Drawing.Point(265, 64);
            this.lbMorada.Name = "lbMorada";
            this.lbMorada.Size = new System.Drawing.Size(0, 13);
            this.lbMorada.TabIndex = 15;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.Location = new System.Drawing.Point(755, 42);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(51, 17);
            this.label4.TabIndex = 16;
            this.label4.Text = "Valor:";
            // 
            // lbTotal
            // 
            this.lbTotal.AutoSize = true;
            this.lbTotal.Location = new System.Drawing.Point(800, 46);
            this.lbTotal.Name = "lbTotal";
            this.lbTotal.Size = new System.Drawing.Size(31, 13);
            this.lbTotal.TabIndex = 17;
            this.lbTotal.Text = "Total";
            // 
            // lbContacto
            // 
            this.lbContacto.AutoSize = true;
            this.lbContacto.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.clienteBindingSource, "Contacto", true));
            this.lbContacto.Location = new System.Drawing.Point(265, 81);
            this.lbContacto.Name = "lbContacto";
            this.lbContacto.Size = new System.Drawing.Size(0, 13);
            this.lbContacto.TabIndex = 18;
            // 
            // toolStrip1
            // 
            this.toolStrip1.BackColor = System.Drawing.Color.Transparent;
            this.toolStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.sairToolStripMenuItem});
            this.toolStrip1.Location = new System.Drawing.Point(0, 0);
            this.toolStrip1.Name = "toolStrip1";
            this.toolStrip1.Size = new System.Drawing.Size(887, 25);
            this.toolStrip1.TabIndex = 19;
            this.toolStrip1.Text = "toolStrip1";
            // 
            // sairToolStripMenuItem
            // 
            this.sairToolStripMenuItem.Alignment = System.Windows.Forms.ToolStripItemAlignment.Right;
            this.sairToolStripMenuItem.Name = "sairToolStripMenuItem";
            this.sairToolStripMenuItem.Size = new System.Drawing.Size(26, 22);
            this.sairToolStripMenuItem.Text = "Sair";
            this.sairToolStripMenuItem.Click += new System.EventHandler(this.sairToolStripMenuItem_Click);
            // 
            // clienteBindingSource
            // 
            this.clienteBindingSource.DataSource = typeof(ProjetoStandOficina.Cliente);
            // 
            // parcelasBindingSource
            // 
            this.parcelasBindingSource.DataSource = typeof(ProjetoStandOficina.Parcela);
            // 
            // servicosBindingSource
            // 
            this.servicosBindingSource.DataSource = typeof(ProjetoStandOficina.Servico);
            // 
            // FormOficina
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.ControlLightLight;
            this.ClientSize = new System.Drawing.Size(887, 447);
            this.ControlBox = false;
            this.Controls.Add(this.toolStrip1);
            this.Controls.Add(this.lbContacto);
            this.Controls.Add(this.lbTotal);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.lbMorada);
            this.Controls.Add(this.lbNif);
            this.Controls.Add(this.lbNome);
            this.Controls.Add(this.groupBox4);
            this.Controls.Add(this.groupBox3);
            this.Controls.Add(this.groupBox2);
            this.Controls.Add(this.groupBox1);
            this.Name = "FormOficina";
            this.Text = "FormOficina";
            this.Load += new System.EventHandler(this.FormOficina_Load);
            this.groupBox1.ResumeLayout(false);
            this.groupBox2.ResumeLayout(false);
            this.groupBox3.ResumeLayout(false);
            this.groupBox4.ResumeLayout(false);
            this.groupBox4.PerformLayout();
            this.toolStrip1.ResumeLayout(false);
            this.toolStrip1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.clienteBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.parcelasBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.servicosBindingSource)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.ListBox listBoxCliente;
        private System.Windows.Forms.Button btnICarro;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.ListBox listBoxCarro;
        private System.Windows.Forms.ListBox listBoxServico;
        private System.Windows.Forms.ListBox listBoxParcela;
        private System.Windows.Forms.Button btnIServico;
        private System.Windows.Forms.Button btnIParcela;
        private System.Windows.Forms.GroupBox groupBox2;
        private System.Windows.Forms.GroupBox groupBox3;
        private System.Windows.Forms.ComboBox comboBox1;
        private System.Windows.Forms.GroupBox groupBox4;
        private System.Windows.Forms.TextBox valorTextBox;
        private System.Windows.Forms.BindingSource parcelasBindingSource;
        private System.Windows.Forms.TextBox descricaoTextBox;
        private System.Windows.Forms.BindingSource servicosBindingSource;
        private System.Windows.Forms.Label lbNome;
        private System.Windows.Forms.Label lbNif;
        private System.Windows.Forms.Label lbMorada;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label lbTotal;
        private System.Windows.Forms.Label lbContacto;
        private System.Windows.Forms.BindingSource clienteBindingSource;
        private System.Windows.Forms.ToolStrip toolStrip1;
        private System.Windows.Forms.ToolStripLabel sairToolStripMenuItem;
    }
}