﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ProjetoStandOficina
{
    public partial class Aluguer
    {

        public override string ToString()
        {
            return "ID Aluguer"+ IdAluguer+" Data Inicio:"+DataInicio+" Kms:"+Kms+" Valor:"+
                Valor+" Data Fim:"+DataFim;
        }

    }
}
