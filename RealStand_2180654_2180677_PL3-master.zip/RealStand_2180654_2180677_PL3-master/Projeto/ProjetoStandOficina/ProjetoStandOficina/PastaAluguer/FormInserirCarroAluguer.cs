﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace ProjetoStandOficina.PastaAluguer
{
    public partial class FormInserirCarroAluguer : Form
    {
        private BaseDadosOficinaContainer basedadosO;
        public FormInserirCarroAluguer(BaseDadosOficinaContainer basedadosO)
        {
            InitializeComponent();
            this.basedadosO = basedadosO;
            btnSair.Enabled = true;
        }

        private void btnICarro_Click(object sender, EventArgs e)
        {
            if (maskedTextBoxMatricula.Text=="" || comboBoxEstado.Text == "" || marcaTextBox.Text==""|| numeroChassisTextBox.Text==""|| comboBoxCombustivel.Text==""|| comboBoxEstado.Text =="")
            {
                MessageBox.Show("Preencha todos os campos!");
                return;
            }

            //gera um carro com caratecristicas de aluguer novo 
            CarroAluguer carroAluguer = new CarroAluguer();

            //CAMPOS
            //MODELO E MARCA
            carroAluguer.Modelo = modeloTextBox.Text;
            carroAluguer.Marca = marcaTextBox.Text;
            //CHASSI E MATRICULA
            //Verificar se o nº de chassi já existe
            foreach (CarroAluguer carroAluguerverificar in basedadosO.Carros.OfType<CarroAluguer>())
            {
                if((carroAluguerverificar.NumeroChassis == Convert.ToString(numeroChassisTextBox.Text)) || (carroAluguerverificar.Matricula == Convert.ToString(maskedTextBoxMatricula.Text)))
                {
                    MessageBox.Show("Este Carro já foi inserido verifique Nº de Chassi ou a Matricula já existe.");
                    return;
                }
                else
                {
                    carroAluguer.NumeroChassis = numeroChassisTextBox.Text;
                    carroAluguer.Matricula = maskedTextBoxMatricula.Text;
                }
            }
            //COMBUSTIVEL E ESTADO
            carroAluguer.Combustivel = comboBoxCombustivel.Text;
            carroAluguer.Estado = comboBoxEstado.Text;


            //Add o carro aluguer
            basedadosO.Carros.Add(carroAluguer);

            //salvar na base de dados o novo carroOficina
            basedadosO.SaveChanges();
            //Menssagem de sucesso
            MessageBox.Show("Carro inscrito com sucesso!", "Aluguer!");
            this.Close();
        }
        //botão sair
        private void btnSair_Click(object sender, EventArgs e)
        {
            if (MessageBox.Show("Sair!", "Deseja sair sem salvar?", MessageBoxButtons.YesNo) == DialogResult.Yes)
            {
                this.Close();
            }
            else
            {
                btnSair.Enabled = false;
            }
        }

    }
}
