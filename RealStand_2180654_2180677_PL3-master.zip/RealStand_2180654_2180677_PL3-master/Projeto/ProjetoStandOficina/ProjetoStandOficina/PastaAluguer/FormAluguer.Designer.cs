﻿namespace ProjetoStandOficina
{
    partial class FormAluguer
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.lbClienteContacto = new System.Windows.Forms.Label();
            this.lbClienteMorada = new System.Windows.Forms.Label();
            this.lbClienteNif = new System.Windows.Forms.Label();
            this.lbClienteNome = new System.Windows.Forms.Label();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.listBoxCliente = new System.Windows.Forms.ListBox();
            this.toolStrip1 = new System.Windows.Forms.ToolStrip();
            this.sairToolStripMenuItem = new System.Windows.Forms.ToolStripLabel();
            this.listBoxCarro = new System.Windows.Forms.ListBox();
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.btnICarro = new System.Windows.Forms.Button();
            this.groupBoxAluguer = new System.Windows.Forms.GroupBox();
            this.lbAluguerValor = new System.Windows.Forms.Label();
            this.lbAluguerKms = new System.Windows.Forms.Label();
            this.lbAluguerDataFim = new System.Windows.Forms.Label();
            this.lbAluguerDataInicio = new System.Windows.Forms.Label();
            this.lbIDAluguer = new System.Windows.Forms.Label();
            this.btnEAluguer = new System.Windows.Forms.Button();
            this.btnIAluguer = new System.Windows.Forms.Button();
            this.listBoxAluguer = new System.Windows.Forms.ListBox();
            this.lbCarroCombustivel = new System.Windows.Forms.Label();
            this.lbCarroModelo = new System.Windows.Forms.Label();
            this.lbCarroNChassi = new System.Windows.Forms.Label();
            this.lbCarroMarca = new System.Windows.Forms.Label();
            this.lbCarroMatricula = new System.Windows.Forms.Label();
            this.lbCarroEstado = new System.Windows.Forms.Label();
            this.groupBox1.SuspendLayout();
            this.toolStrip1.SuspendLayout();
            this.groupBox2.SuspendLayout();
            this.groupBoxAluguer.SuspendLayout();
            this.SuspendLayout();
            // 
            // lbClienteContacto
            // 
            this.lbClienteContacto.AutoSize = true;
            this.lbClienteContacto.Location = new System.Drawing.Point(277, 96);
            this.lbClienteContacto.Name = "lbClienteContacto";
            this.lbClienteContacto.Size = new System.Drawing.Size(0, 13);
            this.lbClienteContacto.TabIndex = 31;
            // 
            // lbClienteMorada
            // 
            this.lbClienteMorada.AutoSize = true;
            this.lbClienteMorada.Location = new System.Drawing.Point(277, 79);
            this.lbClienteMorada.Name = "lbClienteMorada";
            this.lbClienteMorada.Size = new System.Drawing.Size(0, 13);
            this.lbClienteMorada.TabIndex = 30;
            // 
            // lbClienteNif
            // 
            this.lbClienteNif.AutoSize = true;
            this.lbClienteNif.Location = new System.Drawing.Point(277, 63);
            this.lbClienteNif.Name = "lbClienteNif";
            this.lbClienteNif.Size = new System.Drawing.Size(0, 13);
            this.lbClienteNif.TabIndex = 29;
            // 
            // lbClienteNome
            // 
            this.lbClienteNome.AutoSize = true;
            this.lbClienteNome.Font = new System.Drawing.Font("Microsoft Sans Serif", 11F, System.Drawing.FontStyle.Bold);
            this.lbClienteNome.Location = new System.Drawing.Point(252, 43);
            this.lbClienteNome.Name = "lbClienteNome";
            this.lbClienteNome.Size = new System.Drawing.Size(197, 18);
            this.lbClienteNome.TabIndex = 28;
            this.lbClienteNome.Text = "Sem Cliente Selecionado";
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.listBoxCliente);
            this.groupBox1.Location = new System.Drawing.Point(12, 33);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(234, 572);
            this.groupBox1.TabIndex = 27;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "Seleciona um Cliente";
            // 
            // listBoxCliente
            // 
            this.listBoxCliente.FormattingEnabled = true;
            this.listBoxCliente.Location = new System.Drawing.Point(8, 26);
            this.listBoxCliente.Name = "listBoxCliente";
            this.listBoxCliente.Size = new System.Drawing.Size(221, 537);
            this.listBoxCliente.TabIndex = 0;
            this.listBoxCliente.SelectedIndexChanged += new System.EventHandler(this.listBoxCliente_SelectedIndexChanged);
            // 
            // toolStrip1
            // 
            this.toolStrip1.BackColor = System.Drawing.Color.Transparent;
            this.toolStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.sairToolStripMenuItem});
            this.toolStrip1.Location = new System.Drawing.Point(0, 0);
            this.toolStrip1.Name = "toolStrip1";
            this.toolStrip1.Size = new System.Drawing.Size(884, 25);
            this.toolStrip1.TabIndex = 26;
            this.toolStrip1.Text = "toolStrip1";
            // 
            // sairToolStripMenuItem
            // 
            this.sairToolStripMenuItem.Alignment = System.Windows.Forms.ToolStripItemAlignment.Right;
            this.sairToolStripMenuItem.Name = "sairToolStripMenuItem";
            this.sairToolStripMenuItem.Size = new System.Drawing.Size(26, 22);
            this.sairToolStripMenuItem.Text = "Sair";
            this.sairToolStripMenuItem.Click += new System.EventHandler(this.sairToolStripMenuItem_Click);
            // 
            // listBoxCarro
            // 
            this.listBoxCarro.FormattingEnabled = true;
            this.listBoxCarro.Location = new System.Drawing.Point(1, 19);
            this.listBoxCarro.Name = "listBoxCarro";
            this.listBoxCarro.Size = new System.Drawing.Size(227, 511);
            this.listBoxCarro.TabIndex = 5;
            this.listBoxCarro.SelectedIndexChanged += new System.EventHandler(this.listBoxCarro_SelectedIndexChanged);
            // 
            // groupBox2
            // 
            this.groupBox2.Controls.Add(this.listBoxCarro);
            this.groupBox2.Controls.Add(this.btnICarro);
            this.groupBox2.Location = new System.Drawing.Point(638, 33);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Size = new System.Drawing.Size(234, 572);
            this.groupBox2.TabIndex = 33;
            this.groupBox2.TabStop = false;
            this.groupBox2.Text = "Carro FormAluguer";
            // 
            // btnICarro
            // 
            this.btnICarro.BackColor = System.Drawing.Color.DarkOrange;
            this.btnICarro.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.btnICarro.Font = new System.Drawing.Font("Microsoft Sans Serif", 8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnICarro.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.btnICarro.Location = new System.Drawing.Point(6, 539);
            this.btnICarro.Name = "btnICarro";
            this.btnICarro.Size = new System.Drawing.Size(222, 24);
            this.btnICarro.TabIndex = 2;
            this.btnICarro.Text = "Inserir Carro";
            this.btnICarro.UseVisualStyleBackColor = false;
            this.btnICarro.Click += new System.EventHandler(this.btnICarro_Click);
            // 
            // groupBoxAluguer
            // 
            this.groupBoxAluguer.Controls.Add(this.lbAluguerValor);
            this.groupBoxAluguer.Controls.Add(this.lbAluguerKms);
            this.groupBoxAluguer.Controls.Add(this.lbAluguerDataFim);
            this.groupBoxAluguer.Controls.Add(this.lbAluguerDataInicio);
            this.groupBoxAluguer.Controls.Add(this.lbIDAluguer);
            this.groupBoxAluguer.Controls.Add(this.btnEAluguer);
            this.groupBoxAluguer.Controls.Add(this.btnIAluguer);
            this.groupBoxAluguer.Controls.Add(this.listBoxAluguer);
            this.groupBoxAluguer.Location = new System.Drawing.Point(251, 323);
            this.groupBoxAluguer.Name = "groupBoxAluguer";
            this.groupBoxAluguer.Size = new System.Drawing.Size(383, 282);
            this.groupBoxAluguer.TabIndex = 34;
            this.groupBoxAluguer.TabStop = false;
            this.groupBoxAluguer.Text = "Aluguer";
            // 
            // lbAluguerValor
            // 
            this.lbAluguerValor.AutoSize = true;
            this.lbAluguerValor.Location = new System.Drawing.Point(30, 110);
            this.lbAluguerValor.Name = "lbAluguerValor";
            this.lbAluguerValor.Size = new System.Drawing.Size(0, 13);
            this.lbAluguerValor.TabIndex = 9;
            // 
            // lbAluguerKms
            // 
            this.lbAluguerKms.AutoSize = true;
            this.lbAluguerKms.Location = new System.Drawing.Point(30, 90);
            this.lbAluguerKms.Name = "lbAluguerKms";
            this.lbAluguerKms.Size = new System.Drawing.Size(0, 13);
            this.lbAluguerKms.TabIndex = 8;
            // 
            // lbAluguerDataFim
            // 
            this.lbAluguerDataFim.AutoSize = true;
            this.lbAluguerDataFim.Location = new System.Drawing.Point(30, 70);
            this.lbAluguerDataFim.Name = "lbAluguerDataFim";
            this.lbAluguerDataFim.Size = new System.Drawing.Size(0, 13);
            this.lbAluguerDataFim.TabIndex = 7;
            // 
            // lbAluguerDataInicio
            // 
            this.lbAluguerDataInicio.AutoSize = true;
            this.lbAluguerDataInicio.Location = new System.Drawing.Point(30, 50);
            this.lbAluguerDataInicio.Name = "lbAluguerDataInicio";
            this.lbAluguerDataInicio.Size = new System.Drawing.Size(0, 13);
            this.lbAluguerDataInicio.TabIndex = 6;
            // 
            // lbIDAluguer
            // 
            this.lbIDAluguer.AutoSize = true;
            this.lbIDAluguer.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbIDAluguer.Location = new System.Drawing.Point(16, 25);
            this.lbIDAluguer.Name = "lbIDAluguer";
            this.lbIDAluguer.Size = new System.Drawing.Size(349, 40);
            this.lbIDAluguer.TabIndex = 5;
            this.lbIDAluguer.Text = "1º Passo:Selecione um cliente e carro.\r\n2º Passo: Seleciono alguer, caso não tenh" +
    "a crie.";
            // 
            // btnEAluguer
            // 
            this.btnEAluguer.BackColor = System.Drawing.Color.DarkOrange;
            this.btnEAluguer.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.btnEAluguer.Font = new System.Drawing.Font("Microsoft Sans Serif", 8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnEAluguer.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.btnEAluguer.Location = new System.Drawing.Point(264, 109);
            this.btnEAluguer.Name = "btnEAluguer";
            this.btnEAluguer.Size = new System.Drawing.Size(113, 24);
            this.btnEAluguer.TabIndex = 4;
            this.btnEAluguer.Text = "Eliminar Aluguer";
            this.btnEAluguer.UseVisualStyleBackColor = false;
            this.btnEAluguer.Click += new System.EventHandler(this.btnEAluguer_Click);
            // 
            // btnIAluguer
            // 
            this.btnIAluguer.BackColor = System.Drawing.Color.DarkOrange;
            this.btnIAluguer.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.btnIAluguer.Font = new System.Drawing.Font("Microsoft Sans Serif", 8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnIAluguer.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.btnIAluguer.Location = new System.Drawing.Point(264, 79);
            this.btnIAluguer.Name = "btnIAluguer";
            this.btnIAluguer.Size = new System.Drawing.Size(113, 24);
            this.btnIAluguer.TabIndex = 3;
            this.btnIAluguer.Text = "Inserir Aluguer";
            this.btnIAluguer.UseVisualStyleBackColor = false;
            this.btnIAluguer.Click += new System.EventHandler(this.btIAluguer_Click);
            // 
            // listBoxAluguer
            // 
            this.listBoxAluguer.FormattingEnabled = true;
            this.listBoxAluguer.Location = new System.Drawing.Point(6, 139);
            this.listBoxAluguer.Name = "listBoxAluguer";
            this.listBoxAluguer.Size = new System.Drawing.Size(371, 134);
            this.listBoxAluguer.TabIndex = 0;
            this.listBoxAluguer.SelectedIndexChanged += new System.EventHandler(this.listBoxAluguer_SelectedIndexChanged);
            // 
            // lbCarroCombustivel
            // 
            this.lbCarroCombustivel.AutoSize = true;
            this.lbCarroCombustivel.Location = new System.Drawing.Point(277, 264);
            this.lbCarroCombustivel.Name = "lbCarroCombustivel";
            this.lbCarroCombustivel.Size = new System.Drawing.Size(0, 13);
            this.lbCarroCombustivel.TabIndex = 49;
            // 
            // lbCarroModelo
            // 
            this.lbCarroModelo.AutoSize = true;
            this.lbCarroModelo.Location = new System.Drawing.Point(277, 231);
            this.lbCarroModelo.Name = "lbCarroModelo";
            this.lbCarroModelo.Size = new System.Drawing.Size(0, 13);
            this.lbCarroModelo.TabIndex = 48;
            // 
            // lbCarroNChassi
            // 
            this.lbCarroNChassi.AutoSize = true;
            this.lbCarroNChassi.Location = new System.Drawing.Point(277, 201);
            this.lbCarroNChassi.Name = "lbCarroNChassi";
            this.lbCarroNChassi.Size = new System.Drawing.Size(0, 13);
            this.lbCarroNChassi.TabIndex = 47;
            // 
            // lbCarroMarca
            // 
            this.lbCarroMarca.AutoSize = true;
            this.lbCarroMarca.Location = new System.Drawing.Point(277, 216);
            this.lbCarroMarca.Name = "lbCarroMarca";
            this.lbCarroMarca.Size = new System.Drawing.Size(0, 13);
            this.lbCarroMarca.TabIndex = 46;
            // 
            // lbCarroMatricula
            // 
            this.lbCarroMatricula.AutoSize = true;
            this.lbCarroMatricula.Font = new System.Drawing.Font("Microsoft Sans Serif", 11F, System.Drawing.FontStyle.Bold);
            this.lbCarroMatricula.Location = new System.Drawing.Point(252, 180);
            this.lbCarroMatricula.Name = "lbCarroMatricula";
            this.lbCarroMatricula.Size = new System.Drawing.Size(188, 18);
            this.lbCarroMatricula.TabIndex = 45;
            this.lbCarroMatricula.Text = "Sem Carro Selecionado";
            // 
            // lbCarroEstado
            // 
            this.lbCarroEstado.AutoSize = true;
            this.lbCarroEstado.Location = new System.Drawing.Point(277, 247);
            this.lbCarroEstado.Name = "lbCarroEstado";
            this.lbCarroEstado.Size = new System.Drawing.Size(0, 13);
            this.lbCarroEstado.TabIndex = 50;
            // 
            // FormAluguer
            // 
            this.AllowDrop = true;
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.AutoScroll = true;
            this.AutoSize = true;
            this.BackColor = System.Drawing.SystemColors.ControlLightLight;
            this.ClientSize = new System.Drawing.Size(884, 611);
            this.ControlBox = false;
            this.Controls.Add(this.lbCarroEstado);
            this.Controls.Add(this.lbCarroCombustivel);
            this.Controls.Add(this.lbCarroModelo);
            this.Controls.Add(this.lbCarroNChassi);
            this.Controls.Add(this.lbCarroMarca);
            this.Controls.Add(this.lbCarroMatricula);
            this.Controls.Add(this.groupBoxAluguer);
            this.Controls.Add(this.groupBox2);
            this.Controls.Add(this.lbClienteContacto);
            this.Controls.Add(this.lbClienteMorada);
            this.Controls.Add(this.lbClienteNif);
            this.Controls.Add(this.lbClienteNome);
            this.Controls.Add(this.groupBox1);
            this.Controls.Add(this.toolStrip1);
            this.Name = "FormAluguer";
            this.Text = "Aluguer";
            this.Load += new System.EventHandler(this.FormAluguer_Load);
            this.groupBox1.ResumeLayout(false);
            this.toolStrip1.ResumeLayout(false);
            this.toolStrip1.PerformLayout();
            this.groupBox2.ResumeLayout(false);
            this.groupBoxAluguer.ResumeLayout(false);
            this.groupBoxAluguer.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label lbClienteContacto;
        private System.Windows.Forms.Label lbClienteMorada;
        private System.Windows.Forms.Label lbClienteNif;
        private System.Windows.Forms.Label lbClienteNome;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.ListBox listBoxCliente;
        private System.Windows.Forms.ToolStrip toolStrip1;
        private System.Windows.Forms.ToolStripLabel sairToolStripMenuItem;
        private System.Windows.Forms.ListBox listBoxCarro;
        private System.Windows.Forms.GroupBox groupBox2;
        private System.Windows.Forms.Button btnICarro;
        private System.Windows.Forms.GroupBox groupBoxAluguer;
        private System.Windows.Forms.Button btnEAluguer;
        private System.Windows.Forms.Button btnIAluguer;
        private System.Windows.Forms.ListBox listBoxAluguer;
        private System.Windows.Forms.Label lbCarroCombustivel;
        private System.Windows.Forms.Label lbCarroModelo;
        private System.Windows.Forms.Label lbCarroNChassi;
        private System.Windows.Forms.Label lbCarroMarca;
        private System.Windows.Forms.Label lbCarroMatricula;
        private System.Windows.Forms.Label lbCarroEstado;
        private System.Windows.Forms.Label lbAluguerValor;
        private System.Windows.Forms.Label lbAluguerKms;
        private System.Windows.Forms.Label lbAluguerDataFim;
        private System.Windows.Forms.Label lbAluguerDataInicio;
        private System.Windows.Forms.Label lbIDAluguer;
    }
}