﻿namespace ProjetoStandOficina.PastaAluguer
{
    partial class FormInserirAluguer
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.Windows.Forms.Label dataFimLabel;
            System.Windows.Forms.Label kmsLabel;
            System.Windows.Forms.Label valorLabel;
            this.alugueresBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.dataFimDateTimePicker = new System.Windows.Forms.DateTimePicker();
            this.kmsTextBox = new System.Windows.Forms.TextBox();
            this.valorTextBox = new System.Windows.Forms.TextBox();
            this.btnIAluguer = new System.Windows.Forms.Button();
            this.btnSair = new System.Windows.Forms.Button();
            dataFimLabel = new System.Windows.Forms.Label();
            kmsLabel = new System.Windows.Forms.Label();
            valorLabel = new System.Windows.Forms.Label();
            ((System.ComponentModel.ISupportInitialize)(this.alugueresBindingSource)).BeginInit();
            this.SuspendLayout();
            // 
            // dataFimLabel
            // 
            dataFimLabel.AutoSize = true;
            dataFimLabel.Location = new System.Drawing.Point(17, 99);
            dataFimLabel.Name = "dataFimLabel";
            dataFimLabel.Size = new System.Drawing.Size(52, 13);
            dataFimLabel.TabIndex = 1;
            dataFimLabel.Text = "Data Fim:";
            // 
            // kmsLabel
            // 
            kmsLabel.AutoSize = true;
            kmsLabel.Location = new System.Drawing.Point(39, 48);
            kmsLabel.Name = "kmsLabel";
            kmsLabel.Size = new System.Drawing.Size(30, 13);
            kmsLabel.TabIndex = 4;
            kmsLabel.Text = "Kms:";
            // 
            // valorLabel
            // 
            valorLabel.AutoSize = true;
            valorLabel.Location = new System.Drawing.Point(35, 74);
            valorLabel.Name = "valorLabel";
            valorLabel.Size = new System.Drawing.Size(34, 13);
            valorLabel.TabIndex = 6;
            valorLabel.Text = "Valor:";
            // 
            // alugueresBindingSource
            // 
            this.alugueresBindingSource.DataSource = typeof(ProjetoStandOficina.Aluguer);
            // 
            // dataFimDateTimePicker
            // 
            this.dataFimDateTimePicker.DataBindings.Add(new System.Windows.Forms.Binding("Value", this.alugueresBindingSource, "DataFim", true));
            this.dataFimDateTimePicker.Location = new System.Drawing.Point(75, 95);
            this.dataFimDateTimePicker.MinDate = new System.DateTime(2019, 6, 13, 0, 0, 0, 0);
            this.dataFimDateTimePicker.Name = "dataFimDateTimePicker";
            this.dataFimDateTimePicker.Size = new System.Drawing.Size(200, 20);
            this.dataFimDateTimePicker.TabIndex = 2;
            this.dataFimDateTimePicker.Value = new System.DateTime(2019, 6, 13, 13, 3, 0, 0);
            // 
            // kmsTextBox
            // 
            this.kmsTextBox.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.alugueresBindingSource, "Kms", true));
            this.kmsTextBox.Location = new System.Drawing.Point(75, 45);
            this.kmsTextBox.Name = "kmsTextBox";
            this.kmsTextBox.Size = new System.Drawing.Size(200, 20);
            this.kmsTextBox.TabIndex = 5;
            // 
            // valorTextBox
            // 
            this.valorTextBox.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.alugueresBindingSource, "Valor", true));
            this.valorTextBox.Location = new System.Drawing.Point(75, 71);
            this.valorTextBox.Name = "valorTextBox";
            this.valorTextBox.Size = new System.Drawing.Size(200, 20);
            this.valorTextBox.TabIndex = 7;
            // 
            // btnIAluguer
            // 
            this.btnIAluguer.BackColor = System.Drawing.Color.DarkOrange;
            this.btnIAluguer.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.btnIAluguer.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnIAluguer.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.btnIAluguer.Location = new System.Drawing.Point(160, 137);
            this.btnIAluguer.Name = "btnIAluguer";
            this.btnIAluguer.Size = new System.Drawing.Size(115, 23);
            this.btnIAluguer.TabIndex = 8;
            this.btnIAluguer.Text = "Inserir Aluguer";
            this.btnIAluguer.UseVisualStyleBackColor = false;
            this.btnIAluguer.Click += new System.EventHandler(this.btnIAluguer_Click);
            // 
            // btnSair
            // 
            this.btnSair.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.btnSair.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnSair.ForeColor = System.Drawing.Color.DarkOrange;
            this.btnSair.Location = new System.Drawing.Point(221, 3);
            this.btnSair.Name = "btnSair";
            this.btnSair.Size = new System.Drawing.Size(75, 23);
            this.btnSair.TabIndex = 19;
            this.btnSair.Text = "Sair";
            this.btnSair.UseVisualStyleBackColor = true;
            this.btnSair.Click += new System.EventHandler(this.btnSair_Click);
            // 
            // FormInserirAluguer
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.AutoSize = true;
            this.BackColor = System.Drawing.SystemColors.ControlLightLight;
            this.ClientSize = new System.Drawing.Size(300, 181);
            this.ControlBox = false;
            this.Controls.Add(this.btnSair);
            this.Controls.Add(this.btnIAluguer);
            this.Controls.Add(valorLabel);
            this.Controls.Add(this.valorTextBox);
            this.Controls.Add(kmsLabel);
            this.Controls.Add(this.kmsTextBox);
            this.Controls.Add(dataFimLabel);
            this.Controls.Add(this.dataFimDateTimePicker);
            this.MaximizeBox = false;
            this.MinimizeBox = false;
            this.Name = "FormInserirAluguer";
            this.Text = "Inserir - Aluguer";
            ((System.ComponentModel.ISupportInitialize)(this.alugueresBindingSource)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.BindingSource alugueresBindingSource;
        private System.Windows.Forms.DateTimePicker dataFimDateTimePicker;
        private System.Windows.Forms.TextBox kmsTextBox;
        private System.Windows.Forms.TextBox valorTextBox;
        private System.Windows.Forms.Button btnIAluguer;
        private System.Windows.Forms.Button btnSair;
    }
}