﻿using ProjetoStandOficina.PastaAluguer;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace ProjetoStandOficina
{
    public partial class FormAluguer : Form
    {
        private BaseDadosOficinaContainer basedadosO;
        public FormAluguer()
        {
            InitializeComponent();

        }
        private void FormAluguer_Load(object sender, EventArgs e)
        {

            this.basedadosO = new BaseDadosOficinaContainer();
            AtualizarListaCliente();
            AtualizarListaCarrosAluguer();
        }

        #region "Atulizar Listas"
        private void AtualizarListaCliente()
        {
            listBoxCliente.DataSource = basedadosO.Clientes.ToList();

        }
        private void AtualizarListaCarrosAluguer()
        {
            listBoxCarro.DataSource = basedadosO.Carros.OfType<CarroAluguer>().ToList();

        }

        private void AtualizarListaAluguer()
        {
            Cliente clienteSelecionado = listBoxCliente.SelectedItem as Cliente;
            CarroAluguer carroAluguerSelecionado= listBoxCarro.SelectedItem as CarroAluguer;

            int pos = listBoxAluguer.SelectedIndex; //guardar posição do index
            listBoxAluguer.DataSource = null;
            if (clienteSelecionado == null|| carroAluguerSelecionado==null) // se não existir clientes sai
            {
                groupBoxAluguer.Enabled = false;

                lbCarroMatricula.Visible = false;
                lbCarroNChassi.Visible = false;
                lbCarroMarca.Visible = false;
                lbCarroModelo.Visible = false;
                lbCarroCombustivel.Visible = false;
                lbCarroEstado.Enabled = false;


                return;
            }

            groupBoxAluguer.Enabled = true;

            listBoxAluguer.DataSource = clienteSelecionado.Alugueres.ToList(); //atualiza lista
            if (listBoxAluguer.Items.Count > 0) //se o numero de elementos da lista for maior que 0
            {
                if (pos < listBoxAluguer.Items.Count) //se a posição do index for menor que o numero de elementos na lista
                {
                    listBoxAluguer.SelectedIndex = pos; //seleciona a posição               
                }
                else
                {
                    listBoxAluguer.SelectedIndex = listBoxAluguer.Items.Count - 1; //se não seleciona a posição anterior
                }
            }


        }

        #endregion

        #region "Cliente"
        //Selecionar uma cliente
        private void listBoxCliente_SelectedIndexChanged(object sender, EventArgs e)
        {
            Cliente clienteSelecionado = listBoxCliente.SelectedItem as Cliente;

            //verifica se existe cliente, se não existir sai
            if (clienteSelecionado == null)
            {
                groupBoxAluguer.Enabled = false;
                return;
            }
            //Caso existir          
            groupBoxAluguer.Enabled = true;

            //atualiza as labels com nome,nif,morada,Contacto do cliente
            lbClienteNome.Text = "Nome:" + clienteSelecionado.Nome;
            lbClienteNif.Text = "Nif:" + clienteSelecionado.NIF;
            lbClienteMorada.Text = "Morada:" + clienteSelecionado.Morada;
            lbClienteContacto.Text = "Contacto:" + clienteSelecionado.Contacto;

            AtualizarListaAluguer();

        }
        #endregion

        #region "Carro Aluguer"
        //Selecionar uma carroAluguer
        private void listBoxCarro_SelectedIndexChanged(object sender, EventArgs e)
        {
            CarroAluguer carroAluguerSelecionado = listBoxCarro.SelectedItem as CarroAluguer;

            if (listBoxCarro.SelectedIndex != -1)
            {
                //meter visivel as labels do carro
                lbCarroMatricula.Visible = true;
                lbCarroNChassi.Visible = true;
                lbCarroMarca.Visible = true;
                lbCarroModelo.Visible = true;
                lbCarroCombustivel.Visible = true;
                lbCarroEstado.Enabled = true;

                // Mostrar os dados nas labels do carro
                lbCarroMatricula.Text = "Matricula do Carro:" + carroAluguerSelecionado.Matricula;
                lbCarroNChassi.Text = "Nº de Chassi:" + carroAluguerSelecionado.NumeroChassis;
                lbCarroMarca.Text = "Marca:" + carroAluguerSelecionado.Marca;
                lbCarroModelo.Text = "Modelo:" + carroAluguerSelecionado.Modelo;
                lbCarroCombustivel.Text = "Combustivel:" + carroAluguerSelecionado.Combustivel;
                lbCarroEstado.Text = "Estado:" +carroAluguerSelecionado.Estado;
            }
            else
            {
                //oculta os dados do carro
                lbCarroMatricula.Visible = false;
                lbCarroNChassi.Visible = false;
                lbCarroMarca.Visible = false;
                lbCarroModelo.Visible = false;
                lbCarroCombustivel.Visible = false;
                lbCarroEstado.Enabled = false;
            }
        }
        //botão inserir carro
        private void btnICarro_Click(object sender, EventArgs e)
        {
           
            FormInserirCarroAluguer frmInserirCarroAluguer = new FormInserirCarroAluguer(basedadosO);

            frmInserirCarroAluguer.FormClosed += new FormClosedEventHandler(formcloseCarroaluguer);
            frmInserirCarroAluguer.ShowDialog();
        }

        //Ao fechar o form CarroOficina
        private void formcloseCarroaluguer(object sender, FormClosedEventArgs e)
        {
            //Atualiza a Lista CarroAluguer
            AtualizarListaCarrosAluguer();
        }


    #endregion

        #region "Aluguer"

        private void listBoxAluguer_SelectedIndexChanged(object sender, EventArgs e)
        {
                Aluguer aluguerSelecionado = listBoxAluguer.SelectedItem as Aluguer;

                if (listBoxAluguer.SelectedIndex != -1)
                {
                    //meter visivel as labels do aluguer
                
                    lbIDAluguer.Visible = true;
                    lbAluguerDataInicio.Visible = true;
                    lbAluguerDataFim.Visible = true;
                    lbAluguerKms.Visible = true;
                    lbAluguerValor.Visible = true;


                    // Mostrar os dados nas labels do aluguer
                    lbIDAluguer.Text = "ID Venda:" + aluguerSelecionado.IdAluguer;
                    lbAluguerDataInicio.Text = "Data de Inicio:"+aluguerSelecionado.DataInicio;
                    lbAluguerDataFim.Text = "Data de Fim:" + aluguerSelecionado.DataFim;
                    lbAluguerKms.Text = "Kms:"+aluguerSelecionado.Kms;
                    lbAluguerValor.Text = "Valor:"+aluguerSelecionado.Valor;
                


                }
                else
                {
                    //oculta os dados do aluguer
                    lbIDAluguer.Text = "1º Passo:Selecione um cliente e carro. \n 2º Passo: Seleciono alguer, caso não tenha crie.";
                    lbAluguerDataInicio.Visible = false;
                    lbAluguerDataFim.Visible = false;
                    lbAluguerKms.Visible = false;
                    lbAluguerValor.Visible = false;

                }


            }

        private void btIAluguer_Click(object sender, EventArgs e)
        {
            Cliente clienteSelecionado = listBoxCliente.SelectedItem as Cliente;
            CarroAluguer carroAluguerSelecionado = listBoxCarro.SelectedItem as CarroAluguer;


            if (clienteSelecionado == null || carroAluguerSelecionado == null)
            {
                MessageBox.Show("Não existe nenhum Cliente ou Carro selecionado! Caso não tenha nenhum crie.");
                return;
            }

            if (clienteSelecionado.Alugueres.Any(a => a.DataInicio < DateTime.Now && a.DataFim > DateTime.Now))
            {
                MessageBox.Show("O cliente já está a alugar um carro!");
                return;
            }


            FormInserirAluguer frmInserirAluguer = new FormInserirAluguer(clienteSelecionado, carroAluguerSelecionado, basedadosO);


            frmInserirAluguer.FormClosed += new FormClosedEventHandler(formclosecarroaluguer);
            frmInserirAluguer.ShowDialog();


        }

        //Ao fechar o form CarroOficina
        private void formclosecarroaluguer(object sender, FormClosedEventArgs e)
        {
        //Atualiza a Lista CarroAluguer
        AtualizarListaAluguer();
        }
        //botão eliminar aluguer
        private void btnEAluguer_Click(object sender, EventArgs e)
        {
            Aluguer aluguerSelecionado = listBoxAluguer.SelectedItem as Aluguer;


            if (MessageBox.Show("Deseja eliminar a Aluguer?", "Eliminar Aluguer!", MessageBoxButtons.YesNo) == DialogResult.Yes)
            {
                try
                {
                    //remover aluguer
                    basedadosO.Alugueres.Remove(aluguerSelecionado);
                    basedadosO.SaveChanges();
                    MessageBox.Show("Aluguer foi eliminado com sucesso!", "Eliminar Aluguer!");
                }
                catch (Exception )
                {
                        MessageBox.Show("Erro ao eliminar, tente outra vez!", "Eliminar Aluguer!");
                }
                //atulixar a lista aluguer
                AtualizarListaAluguer();
            }
            else
            {
                MessageBox.Show("Este parcela não foi eliminado.", "Eliminar Aluguer!");
            }
        }
    #endregion

        private void sairToolStripMenuItem_Click(object sender, EventArgs e)
        {
            if (MessageBox.Show("Deseja sair da Janela do Aluguer?", "Sair!", MessageBoxButtons.YesNo) == DialogResult.Yes)
            {
                basedadosO.Dispose();
                this.Close();
            }
        }      
        
    }
}
