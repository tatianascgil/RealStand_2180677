﻿namespace ProjetoStandOficina.PastaAluguer
{
    partial class FormInserirCarroAluguer
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.Windows.Forms.Label numeroChassisLabel;
            System.Windows.Forms.Label modeloLabel;
            System.Windows.Forms.Label matriculaLabel;
            System.Windows.Forms.Label marcaLabel;
            System.Windows.Forms.Label combustivelLabel;
            System.Windows.Forms.Label estadoLabel;
            this.maskedTextBoxMatricula = new System.Windows.Forms.MaskedTextBox();
            this.comboBoxCombustivel = new System.Windows.Forms.ComboBox();
            this.btnICarro = new System.Windows.Forms.Button();
            this.numeroChassisTextBox = new System.Windows.Forms.TextBox();
            this.modeloTextBox = new System.Windows.Forms.TextBox();
            this.marcaTextBox = new System.Windows.Forms.TextBox();
            this.comboBoxEstado = new System.Windows.Forms.ComboBox();
            this.alugueresBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.btnSair = new System.Windows.Forms.Button();
            numeroChassisLabel = new System.Windows.Forms.Label();
            modeloLabel = new System.Windows.Forms.Label();
            matriculaLabel = new System.Windows.Forms.Label();
            marcaLabel = new System.Windows.Forms.Label();
            combustivelLabel = new System.Windows.Forms.Label();
            estadoLabel = new System.Windows.Forms.Label();
            ((System.ComponentModel.ISupportInitialize)(this.alugueresBindingSource)).BeginInit();
            this.SuspendLayout();
            // 
            // numeroChassisLabel
            // 
            numeroChassisLabel.AutoSize = true;
            numeroChassisLabel.Location = new System.Drawing.Point(24, 81);
            numeroChassisLabel.Name = "numeroChassisLabel";
            numeroChassisLabel.Size = new System.Drawing.Size(86, 13);
            numeroChassisLabel.TabIndex = 27;
            numeroChassisLabel.Text = "Numero Chassis:";
            // 
            // modeloLabel
            // 
            modeloLabel.AutoSize = true;
            modeloLabel.Location = new System.Drawing.Point(270, 112);
            modeloLabel.Name = "modeloLabel";
            modeloLabel.Size = new System.Drawing.Size(45, 13);
            modeloLabel.TabIndex = 25;
            modeloLabel.Text = "Modelo:";
            // 
            // matriculaLabel
            // 
            matriculaLabel.AutoSize = true;
            matriculaLabel.Location = new System.Drawing.Point(24, 108);
            matriculaLabel.Name = "matriculaLabel";
            matriculaLabel.Size = new System.Drawing.Size(53, 13);
            matriculaLabel.TabIndex = 23;
            matriculaLabel.Text = "Matricula:";
            // 
            // marcaLabel
            // 
            marcaLabel.AutoSize = true;
            marcaLabel.Location = new System.Drawing.Point(24, 52);
            marcaLabel.Name = "marcaLabel";
            marcaLabel.Size = new System.Drawing.Size(40, 13);
            marcaLabel.TabIndex = 21;
            marcaLabel.Text = "Marca:";
            // 
            // combustivelLabel
            // 
            combustivelLabel.AutoSize = true;
            combustivelLabel.Location = new System.Drawing.Point(270, 82);
            combustivelLabel.Name = "combustivelLabel";
            combustivelLabel.Size = new System.Drawing.Size(67, 13);
            combustivelLabel.TabIndex = 19;
            combustivelLabel.Text = "Combustivel:";
            // 
            // estadoLabel
            // 
            estadoLabel.AutoSize = true;
            estadoLabel.Location = new System.Drawing.Point(272, 52);
            estadoLabel.Name = "estadoLabel";
            estadoLabel.Size = new System.Drawing.Size(43, 13);
            estadoLabel.TabIndex = 34;
            estadoLabel.Text = "Estado:";
            // 
            // maskedTextBoxMatricula
            // 
            this.maskedTextBoxMatricula.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.maskedTextBoxMatricula.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.alugueresBindingSource, "CarroAluguer.Matricula", true));
            this.maskedTextBoxMatricula.Font = new System.Drawing.Font("Microsoft Tai Le", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.maskedTextBoxMatricula.Location = new System.Drawing.Point(83, 105);
            this.maskedTextBoxMatricula.Mask = "aa-aa-aa";
            this.maskedTextBoxMatricula.Name = "maskedTextBoxMatricula";
            this.maskedTextBoxMatricula.Size = new System.Drawing.Size(180, 28);
            this.maskedTextBoxMatricula.TabIndex = 32;
            this.maskedTextBoxMatricula.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // comboBoxCombustivel
            // 
            this.comboBoxCombustivel.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.alugueresBindingSource, "CarroAluguer.Combustivel", true));
            this.comboBoxCombustivel.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.comboBoxCombustivel.FormattingEnabled = true;
            this.comboBoxCombustivel.Items.AddRange(new object[] {
            "Gasolina",
            "Diesel",
            "Eletrico",
            "GPL",
            "Híbrico",
            "Outro"});
            this.comboBoxCombustivel.Location = new System.Drawing.Point(335, 78);
            this.comboBoxCombustivel.Name = "comboBoxCombustivel";
            this.comboBoxCombustivel.Size = new System.Drawing.Size(127, 21);
            this.comboBoxCombustivel.TabIndex = 31;
            // 
            // btnICarro
            // 
            this.btnICarro.BackColor = System.Drawing.Color.DarkOrange;
            this.btnICarro.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.btnICarro.Font = new System.Drawing.Font("Microsoft Sans Serif", 8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnICarro.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.btnICarro.Location = new System.Drawing.Point(297, 145);
            this.btnICarro.Name = "btnICarro";
            this.btnICarro.Size = new System.Drawing.Size(165, 24);
            this.btnICarro.TabIndex = 29;
            this.btnICarro.Text = "Guardar Dados";
            this.btnICarro.UseVisualStyleBackColor = false;
            this.btnICarro.Click += new System.EventHandler(this.btnICarro_Click);
            // 
            // numeroChassisTextBox
            // 
            this.numeroChassisTextBox.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.alugueresBindingSource, "CarroAluguer.NumeroChassis", true));
            this.numeroChassisTextBox.Location = new System.Drawing.Point(110, 78);
            this.numeroChassisTextBox.MaxLength = 17;
            this.numeroChassisTextBox.Name = "numeroChassisTextBox";
            this.numeroChassisTextBox.Size = new System.Drawing.Size(154, 20);
            this.numeroChassisTextBox.TabIndex = 28;
            // 
            // modeloTextBox
            // 
            this.modeloTextBox.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.alugueresBindingSource, "CarroAluguer.Modelo", true));
            this.modeloTextBox.Location = new System.Drawing.Point(321, 109);
            this.modeloTextBox.Name = "modeloTextBox";
            this.modeloTextBox.Size = new System.Drawing.Size(141, 20);
            this.modeloTextBox.TabIndex = 26;
            // 
            // marcaTextBox
            // 
            this.marcaTextBox.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.alugueresBindingSource, "CarroAluguer.Marca", true));
            this.marcaTextBox.Location = new System.Drawing.Point(70, 49);
            this.marcaTextBox.Name = "marcaTextBox";
            this.marcaTextBox.Size = new System.Drawing.Size(193, 20);
            this.marcaTextBox.TabIndex = 24;
            // 
            // comboBoxEstado
            // 
            this.comboBoxEstado.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.comboBoxEstado.FormattingEnabled = true;
            this.comboBoxEstado.Items.AddRange(new object[] {
            "Usado",
            "Novo"});
            this.comboBoxEstado.Location = new System.Drawing.Point(321, 48);
            this.comboBoxEstado.Name = "comboBoxEstado";
            this.comboBoxEstado.Size = new System.Drawing.Size(140, 21);
            this.comboBoxEstado.TabIndex = 35;
            // 
            // alugueresBindingSource
            // 
            this.alugueresBindingSource.DataSource = typeof(ProjetoStandOficina.Aluguer);
            // 
            // btnSair
            // 
            this.btnSair.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.btnSair.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnSair.ForeColor = System.Drawing.Color.DarkOrange;
            this.btnSair.Location = new System.Drawing.Point(397, 5);
            this.btnSair.Name = "btnSair";
            this.btnSair.Size = new System.Drawing.Size(75, 23);
            this.btnSair.TabIndex = 36;
            this.btnSair.Text = "Sair";
            this.btnSair.UseVisualStyleBackColor = true;
            this.btnSair.Click += new System.EventHandler(this.btnSair_Click);
            // 
            // FormInserirCarroAluguer
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.ControlLightLight;
            this.ClientSize = new System.Drawing.Size(484, 191);
            this.ControlBox = false;
            this.Controls.Add(this.btnSair);
            this.Controls.Add(this.comboBoxEstado);
            this.Controls.Add(estadoLabel);
            this.Controls.Add(this.maskedTextBoxMatricula);
            this.Controls.Add(this.comboBoxCombustivel);
            this.Controls.Add(this.btnICarro);
            this.Controls.Add(numeroChassisLabel);
            this.Controls.Add(this.numeroChassisTextBox);
            this.Controls.Add(modeloLabel);
            this.Controls.Add(this.modeloTextBox);
            this.Controls.Add(matriculaLabel);
            this.Controls.Add(marcaLabel);
            this.Controls.Add(this.marcaTextBox);
            this.Controls.Add(combustivelLabel);
            this.Name = "FormInserirCarroAluguer";
            this.Text = "Inserir - Carro Aluguer";
            ((System.ComponentModel.ISupportInitialize)(this.alugueresBindingSource)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion
        private System.Windows.Forms.MaskedTextBox maskedTextBoxMatricula;
        private System.Windows.Forms.BindingSource alugueresBindingSource;
        private System.Windows.Forms.ComboBox comboBoxCombustivel;
        private System.Windows.Forms.Button btnICarro;
        private System.Windows.Forms.TextBox numeroChassisTextBox;
        private System.Windows.Forms.TextBox modeloTextBox;
        private System.Windows.Forms.TextBox marcaTextBox;
        private System.Windows.Forms.ComboBox comboBoxEstado;
        private System.Windows.Forms.Button btnSair;
    }
}