﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace ProjetoStandOficina.PastaAluguer
{
    public partial class FormInserirAluguer : Form
    {
        private BaseDadosOficinaContainer basedadosO;
        private Cliente clienteSelecionado;
        private CarroAluguer carroAluguerSelecionado;

        public FormInserirAluguer(Cliente clienteSelecionado, CarroAluguer carroAluguerSelecionado, BaseDadosOficinaContainer basedadosO)
        {
            InitializeComponent();
            this.carroAluguerSelecionado = carroAluguerSelecionado;
            this.clienteSelecionado = clienteSelecionado;
            this.basedadosO = basedadosO;
        }

        private void btnIAluguer_Click(object sender, EventArgs e)
        {

            Aluguer aluguer = new Aluguer();

            aluguer.CarroAluguer = carroAluguerSelecionado;

            if (kmsTextBox.Text == "" || valorTextBox.Text == "")
            {
                MessageBox.Show("Preencha todos os campos.");
                return;
            }


            //CAMPOSS
            //DATA INICIO
            aluguer.DataInicio = DateTime.Now;

            //KMS
            //Variavel para retorno da conversão 
            double kmss;
            //Utilização do TryParse, para validação do objeto. Verificamos se o mesmo é double    
            if (double.TryParse(kmsTextBox.Text, out kmss))
            {
                aluguer.Kms = Convert.ToDouble(kmsTextBox.Text);
            }
            else
            {
                MessageBox.Show("Tem de introduzir os dados corretamento nos Kms. Informação:Tem de introduzir numeros.");
                return;
            }

            //VALOR
            //Variavel para retorno da conversão 
            double valorr;
            //Utilização do TryParse, para validação do objeto. Verificamos se o mesmo é double    
            if (double.TryParse(valorTextBox.Text, out valorr))
            {
                aluguer.Valor = Convert.ToDouble(valorTextBox.Text);
        }
            else
            {
                MessageBox.Show("Tem de introduzir os dados corretamento no Valor. Informação:Tem de introduzir numeros.");
                return;
            }

            //Custos da impresa 
            switch (aluguer.CarroAluguer.Estado)
            {
                case "Novo":
                    aluguer.Valor += 500;
                    break;

                case "Usado":
                    aluguer.Valor += 70;
                    break;
            }
            //DATA FIM
            aluguer.DataFim = dataFimDateTimePicker.Value.Date;


            //Adicionar aluguer com os campos preenchidos

            clienteSelecionado.Alugueres.Add(aluguer);

            //salvar na base de dados o novo carroAluguer
            basedadosO.SaveChanges();
            this.Close();

        }

        private void btnSair_Click(object sender, EventArgs e)
        {
            if (MessageBox.Show("Sair!", "Deseja sair sem salvar?", MessageBoxButtons.YesNo) == DialogResult.Yes)
            {
                this.Close();
            }
            else
            {
                btnSair.Enabled = false;
            }
        }
    }
}