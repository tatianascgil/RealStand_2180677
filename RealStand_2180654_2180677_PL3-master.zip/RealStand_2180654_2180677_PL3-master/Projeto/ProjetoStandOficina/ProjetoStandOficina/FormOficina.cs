﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace ProjetoStandOficina
{
    public partial class FormOficina : Form
    {
        private BaseDadosOfinaContainer badedadosO;
        public FormOficina()
        {
            InitializeComponent();
        }

        private void FormOficina_Load(object sender, EventArgs e)
        {
            //FormOficina formOficina = new FormOficina();
            // this.formOficina = new Size(140, 480);
            badedadosO = new BaseDadosOfinaContainer();
            LerDadosCliente();
        }

        private void LerDadosCliente()
        {
            listBoxCliente.DataSource = badedadosO.Clientes.ToList<Cliente>();
                    //listBoxCarro.DataSource = badedadosO.Carros.ToList<Carro>();
                    //listBoxServico.DataSource = badedadosO.Servicos.ToList<Servico>();
                    //listBoxParcela.DataSource = badedadosO.Parcelas.ToList<Parcela>();
        }
        private void listBoxCarro_SelectedIndexChanged(object sender, EventArgs e)
        {
            AtualizarListaServico();
        }
        private void listBoxServico_SelectedIndexChanged(object sender, EventArgs e)
        {
            AtualizarListaParcela();
        }
        private void sairToolStripMenuItem_Click(object sender, EventArgs e)
        {
            badedadosO.Dispose();
            this.Close();
        }

    #region "Clientes"
        private void listBoxCliente_SelectedIndexChanged(object sender, EventArgs e)
        {
            //sempre que um cliente é selecionado a seleção muda de imediato
            Cliente cliente = listBoxCliente.SelectedItem as Cliente;

            //verifica se existe cliente, se não existir sai
            if (cliente == null)
            {
                return;
            }
            //Caso existir
            //atualiza as labels com nome,nif,morada,Contacto do cliente
            lbNome.Text = cliente.Nome;
            lbNif.Text = cliente.NIF;
            lbMorada.Text = cliente.Morada;
            lbContacto.Text = cliente.Contacto;

            //atualiza a lista modo a mostrar a lista referente a esse cliente
            AtualizarListaCarro();


        }

        #endregion

    #region "Carros Oficina"
        private void btnICarro_Click(object sender, EventArgs e)
        {
            Cliente clienteSelecionado = listBoxCliente.SelectedItem as Cliente;

            formCarroOficina frmcarro = new formCarroOficina(clienteSelecionado, badedadosO);

            frmcarro.ShowDialog();
            frmcarro.FormClosed += new FormClosedEventHandler(formclose);
            AtualizarListaCarro();


        }

        //Ao fechar o form CarroOficina
        private void formclose(object sender, FormClosedEventArgs e)
        {
            AtualizarListaCarro();
            
        }

        #endregion   #region

    #region "Servicos"

        private void btnIServico_Click(object sender, EventArgs e)
        {
            CarroOficina carroOficinaSelecionado = listBoxCarro.SelectedItem as CarroOficina;
            //se não existir nenhum carro erro: "Não existe nenhum carro!"
            if (carroOficinaSelecionado == null)
            {
                MessageBox.Show("Não existe nenhum Carro!");
                return;
            }

            //se existir cria compra e atualiza a lista e seleciona a compra criada
            Servico servico = new Servico();

            servico.DataEntrada = DateTime.Now.ToShortDateString();
            servico.DataSaida = DateTime.Now.ToLongTimeString();
            servico.Tipo = comboBox1.Text;

            carroOficinaSelecionado.Servicos.Add(servico);
            badedadosO.SaveChanges();
            AtualizarListaServico();

        }
        #endregion

    #region "Parcelas"
        private void btnIParcela_Click(object sender, EventArgs e)
        {
            Servico servisoSelecionado = listBoxServico.SelectedItem as Servico;
            //se não existir nenhum carro erro: "Não existe nenhum carro!"
            if (servisoSelecionado == null)
            {
                MessageBox.Show("Não existe nenhum Serviço selecionado! Caso não tenha nenhum serviço crie.");
                return;
            }

            //se existir cria compra e atualiza a lista e seleciona a compra criada
            Parcela parcela = new Parcela();

            parcela.Valor = valorTextBox.Text;
            parcela.Descricao = descricaoTextBox.Text;

            servisoSelecionado.Parcelas.Add(parcela);
            badedadosO.SaveChanges();
            AtualizarListaParcela();

        }
        #endregion

    #region "Atulizar listas"
        private void AtualizarListaCarro()
                {
                    Cliente cliente = listBoxCliente.SelectedItem as Cliente;
                    int pos = listBoxCarro.SelectedIndex; //guardar posição do index
                    listBoxCarro.DataSource = null;
                    if (cliente == null) // se não existir clientes sai
                    {
                        return;
                    }
                    listBoxCarro.DataSource = cliente.CarroOficina.ToList(); //atualiza lista
                    if (listBoxCarro.Items.Count > 0) //se o numero de elementos da lista for maior que 0
                    {
                        if (pos < listBoxCarro.Items.Count) //se a posição do index for menor que o numero de elementos na lista
                        {
                            listBoxCarro.SelectedIndex = pos; //seleciona a posição
                        }
                        else
                        {
                            listBoxCarro.SelectedIndex = listBoxCarro.Items.Count - 1; //se não seleciona a posição anterior
                        }
                    }
            AtualizarListaServico();

        }
        private void AtualizarListaServico()
        {
            CarroOficina carroOficinaSelecionado = listBoxCarro.SelectedItem as CarroOficina;
            int pos = listBoxServico.SelectedIndex; //guardar posição do index
            listBoxServico.DataSource = null;
            if (carroOficinaSelecionado == null) // se não existir clientes sai
            {
                return;
            }
            listBoxServico.DataSource = carroOficinaSelecionado.Servicos.ToList(); //atualiza lista
            if (listBoxServico.Items.Count > 0) //se o numero de elementos da lista for maior que 0
            {
                if (pos < listBoxServico.Items.Count) //se a posição do index for menor que o numero de elementos na lista
                {
                    listBoxServico.SelectedIndex = pos; //sleciona a posição
                }
                else
                {
                    listBoxServico.SelectedIndex = listBoxServico.Items.Count - 1; //se não seleciona a posição anterior
                }
            }
            AtualizarListaParcela();

        }
        private void AtualizarListaParcela()
        {
            Servico servicoSelecionado = listBoxServico.SelectedItem as Servico;
            int pos = listBoxParcela.SelectedIndex; //guardar posição do index
            listBoxParcela.DataSource = null;
            if (servicoSelecionado == null) // se não existir clientes sai
            {
                return;
            }
            listBoxParcela.DataSource = servicoSelecionado.Parcelas.ToList(); //atualiza lista
            if (listBoxParcela.Items.Count > 0) //se o numero de elementos da lista for maior que 0
            {
                if (pos < listBoxParcela.Items.Count) //se a posição do index for menor que o numero de elementos na lista
                {
                    listBoxParcela.SelectedIndex = pos; //sleciona a posição
                }
                else
                {
                    listBoxParcela.SelectedIndex = listBoxParcela.Items.Count - 1; //se não seleciona a posição anterior
                }
            }

        }
        #endregion     
        
    }
}