﻿namespace ProjetoStandOficina
{
    partial class FormIndex
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.btnGVendas = new System.Windows.Forms.Button();
            this.btnGAluguer = new System.Windows.Forms.Button();
            this.btnGOficina = new System.Windows.Forms.Button();
            this.btnGClientes = new System.Windows.Forms.Button();
            this.label1 = new System.Windows.Forms.Label();
            this.btnSair = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // btnGVendas
            // 
            this.btnGVendas.BackColor = System.Drawing.Color.DarkOrange;
            this.btnGVendas.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.btnGVendas.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnGVendas.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.btnGVendas.Image = global::ProjetoStandOficina.Properties.Resources.imgVenda;
            this.btnGVendas.Location = new System.Drawing.Point(528, 222);
            this.btnGVendas.Name = "btnGVendas";
            this.btnGVendas.Size = new System.Drawing.Size(200, 200);
            this.btnGVendas.TabIndex = 3;
            this.btnGVendas.Text = "Gestão Vendas";
            this.btnGVendas.TextAlign = System.Drawing.ContentAlignment.BottomRight;
            this.btnGVendas.UseVisualStyleBackColor = false;
            this.btnGVendas.Click += new System.EventHandler(this.btnGVendas_Click);
            // 
            // btnGAluguer
            // 
            this.btnGAluguer.BackColor = System.Drawing.Color.DarkOrange;
            this.btnGAluguer.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.btnGAluguer.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnGAluguer.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.btnGAluguer.Image = global::ProjetoStandOficina.Properties.Resources.imgAluguer;
            this.btnGAluguer.Location = new System.Drawing.Point(286, 222);
            this.btnGAluguer.Name = "btnGAluguer";
            this.btnGAluguer.Size = new System.Drawing.Size(200, 200);
            this.btnGAluguer.TabIndex = 2;
            this.btnGAluguer.Text = "Gestão Aluguer";
            this.btnGAluguer.TextAlign = System.Drawing.ContentAlignment.BottomRight;
            this.btnGAluguer.UseVisualStyleBackColor = false;
            this.btnGAluguer.Click += new System.EventHandler(this.btnAluguer_Click);
            // 
            // btnGOficina
            // 
            this.btnGOficina.BackColor = System.Drawing.Color.DarkOrange;
            this.btnGOficina.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.btnGOficina.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnGOficina.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.btnGOficina.Image = global::ProjetoStandOficina.Properties.Resources.imgOficina;
            this.btnGOficina.Location = new System.Drawing.Point(46, 222);
            this.btnGOficina.Name = "btnGOficina";
            this.btnGOficina.Size = new System.Drawing.Size(200, 200);
            this.btnGOficina.TabIndex = 1;
            this.btnGOficina.Text = "Gestão Oficina";
            this.btnGOficina.TextAlign = System.Drawing.ContentAlignment.BottomRight;
            this.btnGOficina.UseVisualStyleBackColor = false;
            this.btnGOficina.Click += new System.EventHandler(this.btnGOficina_Click);
            // 
            // btnGClientes
            // 
            this.btnGClientes.BackColor = System.Drawing.Color.DarkOrange;
            this.btnGClientes.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.btnGClientes.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnGClientes.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.btnGClientes.Image = global::ProjetoStandOficina.Properties.Resources.imgCliente;
            this.btnGClientes.Location = new System.Drawing.Point(46, 12);
            this.btnGClientes.Name = "btnGClientes";
            this.btnGClientes.Size = new System.Drawing.Size(200, 200);
            this.btnGClientes.TabIndex = 0;
            this.btnGClientes.Text = "Gestão Clientes";
            this.btnGClientes.TextAlign = System.Drawing.ContentAlignment.BottomRight;
            this.btnGClientes.UseVisualStyleBackColor = false;
            this.btnGClientes.Click += new System.EventHandler(this.btnGClientes_Click);
            // 
            // label1
            // 
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 30F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.ForeColor = System.Drawing.Color.DarkOrange;
            this.label1.Location = new System.Drawing.Point(492, 52);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(236, 106);
            this.label1.TabIndex = 4;
            this.label1.Text = "Stand      \r\n       Oficina";
            // 
            // btnSair
            // 
            this.btnSair.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.btnSair.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnSair.ForeColor = System.Drawing.Color.DarkOrange;
            this.btnSair.Location = new System.Drawing.Point(697, 12);
            this.btnSair.Name = "btnSair";
            this.btnSair.Size = new System.Drawing.Size(75, 23);
            this.btnSair.TabIndex = 5;
            this.btnSair.Text = "Sair";
            this.btnSair.UseVisualStyleBackColor = true;
            this.btnSair.Click += new System.EventHandler(this.btnSair_Click);
            // 
            // FormIndex
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.ControlLightLight;
            this.ClientSize = new System.Drawing.Size(784, 461);
            this.ControlBox = false;
            this.Controls.Add(this.btnSair);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.btnGVendas);
            this.Controls.Add(this.btnGAluguer);
            this.Controls.Add(this.btnGOficina);
            this.Controls.Add(this.btnGClientes);
            this.MaximizeBox = false;
            this.MinimizeBox = false;
            this.Name = "FormIndex";
            this.Text = "Bem-Vindo ao Stand & Oficina ";
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Button btnGClientes;
        private System.Windows.Forms.Button btnGOficina;
        private System.Windows.Forms.Button btnGAluguer;
        private System.Windows.Forms.Button btnGVendas;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Button btnSair;
    }
}

