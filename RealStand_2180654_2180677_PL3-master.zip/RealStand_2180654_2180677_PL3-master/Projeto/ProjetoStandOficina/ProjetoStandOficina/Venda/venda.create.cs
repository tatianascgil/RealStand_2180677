﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ProjetoStandOficina
{
    public partial class Venda
    {
        public override string ToString()
        {
            return "ID Venda" + IdVenda + " Valor:" + Valor + " Estado:"+Estado+" Data:"+ Data +
                "Nº Chassis:" + CarroVenda.NumeroChassis + " Marca:" + CarroVenda.Marca + " Modelo:" + CarroVenda.Modelo + "Extras:" + CarroVenda.Extras;

        }
    }
}
