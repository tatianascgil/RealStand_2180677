﻿namespace ProjetoStandOficina
{
    partial class FormVenda
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.Windows.Forms.Label estadoLabel;
            System.Windows.Forms.Label valorLabel;
            System.Windows.Forms.Label numeroChassisLabel;
            System.Windows.Forms.Label marcaLabel;
            System.Windows.Forms.Label modeloLabel;
            System.Windows.Forms.Label extrasLabel;
            System.Windows.Forms.Label combustivelLabel;
            this.toolStrip1 = new System.Windows.Forms.ToolStrip();
            this.sairToolStripMenuItem = new System.Windows.Forms.ToolStripLabel();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.listBoxCliente = new System.Windows.Forms.ListBox();
            this.lbClienteContacto = new System.Windows.Forms.Label();
            this.lbClienteMorada = new System.Windows.Forms.Label();
            this.lbClienteNif = new System.Windows.Forms.Label();
            this.lbClienteNome = new System.Windows.Forms.Label();
            this.groupBoxVenda = new System.Windows.Forms.GroupBox();
            this.lbVEstado = new System.Windows.Forms.Label();
            this.lbVValor = new System.Windows.Forms.Label();
            this.lbVData = new System.Windows.Forms.Label();
            this.lbIDVenda = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.comboBoxCombustivel = new System.Windows.Forms.ComboBox();
            this.comboBoxEstado = new System.Windows.Forms.ComboBox();
            this.btEVenda = new System.Windows.Forms.Button();
            this.extrasTextBox = new System.Windows.Forms.TextBox();
            this.vendasBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.modeloTextBox = new System.Windows.Forms.TextBox();
            this.marcaTextBox = new System.Windows.Forms.TextBox();
            this.numeroChassisTextBox = new System.Windows.Forms.TextBox();
            this.valorTextBox = new System.Windows.Forms.TextBox();
            this.lbCarroExtras = new System.Windows.Forms.Label();
            this.lbCarroCombustivel = new System.Windows.Forms.Label();
            this.lbCarroModelo = new System.Windows.Forms.Label();
            this.lbCarroNChassi = new System.Windows.Forms.Label();
            this.lbCarroMarca = new System.Windows.Forms.Label();
            this.lbCarroMatricula = new System.Windows.Forms.Label();
            this.btnIVenda = new System.Windows.Forms.Button();
            this.listBoxVenda = new System.Windows.Forms.ListBox();
            estadoLabel = new System.Windows.Forms.Label();
            valorLabel = new System.Windows.Forms.Label();
            numeroChassisLabel = new System.Windows.Forms.Label();
            marcaLabel = new System.Windows.Forms.Label();
            modeloLabel = new System.Windows.Forms.Label();
            extrasLabel = new System.Windows.Forms.Label();
            combustivelLabel = new System.Windows.Forms.Label();
            this.toolStrip1.SuspendLayout();
            this.groupBox1.SuspendLayout();
            this.groupBoxVenda.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.vendasBindingSource)).BeginInit();
            this.SuspendLayout();
            // 
            // estadoLabel
            // 
            estadoLabel.AutoSize = true;
            estadoLabel.Location = new System.Drawing.Point(333, 178);
            estadoLabel.Name = "estadoLabel";
            estadoLabel.Size = new System.Drawing.Size(43, 13);
            estadoLabel.TabIndex = 47;
            estadoLabel.Text = "Estado:";
            // 
            // valorLabel
            // 
            valorLabel.AutoSize = true;
            valorLabel.Location = new System.Drawing.Point(511, 178);
            valorLabel.Name = "valorLabel";
            valorLabel.Size = new System.Drawing.Size(34, 13);
            valorLabel.TabIndex = 48;
            valorLabel.Text = "Valor:";
            // 
            // numeroChassisLabel
            // 
            numeroChassisLabel.AutoSize = true;
            numeroChassisLabel.Location = new System.Drawing.Point(334, 213);
            numeroChassisLabel.Name = "numeroChassisLabel";
            numeroChassisLabel.Size = new System.Drawing.Size(86, 13);
            numeroChassisLabel.TabIndex = 49;
            numeroChassisLabel.Text = "Numero Chassis:";
            // 
            // marcaLabel
            // 
            marcaLabel.AutoSize = true;
            marcaLabel.Location = new System.Drawing.Point(334, 248);
            marcaLabel.Name = "marcaLabel";
            marcaLabel.Size = new System.Drawing.Size(40, 13);
            marcaLabel.TabIndex = 50;
            marcaLabel.Text = "Marca:";
            // 
            // modeloLabel
            // 
            modeloLabel.AutoSize = true;
            modeloLabel.Location = new System.Drawing.Point(487, 248);
            modeloLabel.Name = "modeloLabel";
            modeloLabel.Size = new System.Drawing.Size(45, 13);
            modeloLabel.TabIndex = 51;
            modeloLabel.Text = "Modelo:";
            // 
            // extrasLabel
            // 
            extrasLabel.AutoSize = true;
            extrasLabel.Location = new System.Drawing.Point(337, 311);
            extrasLabel.Name = "extrasLabel";
            extrasLabel.Size = new System.Drawing.Size(39, 13);
            extrasLabel.TabIndex = 52;
            extrasLabel.Text = "Extras:";
            // 
            // combustivelLabel
            // 
            combustivelLabel.AutoSize = true;
            combustivelLabel.Location = new System.Drawing.Point(334, 282);
            combustivelLabel.Name = "combustivelLabel";
            combustivelLabel.Size = new System.Drawing.Size(67, 13);
            combustivelLabel.TabIndex = 53;
            combustivelLabel.Text = "Combustivel:";
            // 
            // toolStrip1
            // 
            this.toolStrip1.BackColor = System.Drawing.Color.Transparent;
            this.toolStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.sairToolStripMenuItem});
            this.toolStrip1.Location = new System.Drawing.Point(0, 0);
            this.toolStrip1.Name = "toolStrip1";
            this.toolStrip1.Size = new System.Drawing.Size(884, 25);
            this.toolStrip1.TabIndex = 20;
            this.toolStrip1.Text = "toolStrip1";
            // 
            // sairToolStripMenuItem
            // 
            this.sairToolStripMenuItem.Alignment = System.Windows.Forms.ToolStripItemAlignment.Right;
            this.sairToolStripMenuItem.Name = "sairToolStripMenuItem";
            this.sairToolStripMenuItem.Size = new System.Drawing.Size(26, 22);
            this.sairToolStripMenuItem.Text = "Sair";
            this.sairToolStripMenuItem.Click += new System.EventHandler(this.sairToolStripMenuItem_Click);
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.listBoxCliente);
            this.groupBox1.Location = new System.Drawing.Point(12, 28);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(198, 572);
            this.groupBox1.TabIndex = 21;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "Seleciona um Cliente";
            // 
            // listBoxCliente
            // 
            this.listBoxCliente.FormattingEnabled = true;
            this.listBoxCliente.Location = new System.Drawing.Point(8, 26);
            this.listBoxCliente.Name = "listBoxCliente";
            this.listBoxCliente.Size = new System.Drawing.Size(185, 537);
            this.listBoxCliente.TabIndex = 0;
            this.listBoxCliente.SelectedIndexChanged += new System.EventHandler(this.listBoxCliente_SelectedIndexChanged);
            // 
            // lbClienteContacto
            // 
            this.lbClienteContacto.AutoSize = true;
            this.lbClienteContacto.Location = new System.Drawing.Point(241, 100);
            this.lbClienteContacto.Name = "lbClienteContacto";
            this.lbClienteContacto.Size = new System.Drawing.Size(0, 13);
            this.lbClienteContacto.TabIndex = 25;
            // 
            // lbClienteMorada
            // 
            this.lbClienteMorada.AutoSize = true;
            this.lbClienteMorada.Location = new System.Drawing.Point(241, 83);
            this.lbClienteMorada.Name = "lbClienteMorada";
            this.lbClienteMorada.Size = new System.Drawing.Size(0, 13);
            this.lbClienteMorada.TabIndex = 24;
            // 
            // lbClienteNif
            // 
            this.lbClienteNif.AutoSize = true;
            this.lbClienteNif.Location = new System.Drawing.Point(241, 67);
            this.lbClienteNif.Name = "lbClienteNif";
            this.lbClienteNif.Size = new System.Drawing.Size(0, 13);
            this.lbClienteNif.TabIndex = 23;
            // 
            // lbClienteNome
            // 
            this.lbClienteNome.AutoSize = true;
            this.lbClienteNome.Font = new System.Drawing.Font("Microsoft Sans Serif", 11F, System.Drawing.FontStyle.Bold);
            this.lbClienteNome.Location = new System.Drawing.Point(216, 47);
            this.lbClienteNome.Name = "lbClienteNome";
            this.lbClienteNome.Size = new System.Drawing.Size(197, 18);
            this.lbClienteNome.TabIndex = 22;
            this.lbClienteNome.Text = "Sem Cliente Selecionado";
            // 
            // groupBoxVenda
            // 
            this.groupBoxVenda.Controls.Add(this.lbVEstado);
            this.groupBoxVenda.Controls.Add(this.lbVValor);
            this.groupBoxVenda.Controls.Add(this.lbVData);
            this.groupBoxVenda.Controls.Add(this.lbIDVenda);
            this.groupBoxVenda.Controls.Add(this.label2);
            this.groupBoxVenda.Controls.Add(this.comboBoxCombustivel);
            this.groupBoxVenda.Controls.Add(this.comboBoxEstado);
            this.groupBoxVenda.Controls.Add(this.btEVenda);
            this.groupBoxVenda.Controls.Add(combustivelLabel);
            this.groupBoxVenda.Controls.Add(extrasLabel);
            this.groupBoxVenda.Controls.Add(this.extrasTextBox);
            this.groupBoxVenda.Controls.Add(modeloLabel);
            this.groupBoxVenda.Controls.Add(this.modeloTextBox);
            this.groupBoxVenda.Controls.Add(marcaLabel);
            this.groupBoxVenda.Controls.Add(this.marcaTextBox);
            this.groupBoxVenda.Controls.Add(numeroChassisLabel);
            this.groupBoxVenda.Controls.Add(this.numeroChassisTextBox);
            this.groupBoxVenda.Controls.Add(valorLabel);
            this.groupBoxVenda.Controls.Add(this.valorTextBox);
            this.groupBoxVenda.Controls.Add(estadoLabel);
            this.groupBoxVenda.Controls.Add(this.lbCarroExtras);
            this.groupBoxVenda.Controls.Add(this.lbCarroCombustivel);
            this.groupBoxVenda.Controls.Add(this.lbCarroModelo);
            this.groupBoxVenda.Controls.Add(this.lbCarroNChassi);
            this.groupBoxVenda.Controls.Add(this.lbCarroMarca);
            this.groupBoxVenda.Controls.Add(this.lbCarroMatricula);
            this.groupBoxVenda.Controls.Add(this.btnIVenda);
            this.groupBoxVenda.Controls.Add(this.listBoxVenda);
            this.groupBoxVenda.Enabled = false;
            this.groupBoxVenda.Location = new System.Drawing.Point(211, 162);
            this.groupBoxVenda.Name = "groupBoxVenda";
            this.groupBoxVenda.Size = new System.Drawing.Size(663, 438);
            this.groupBoxVenda.TabIndex = 38;
            this.groupBoxVenda.TabStop = false;
            this.groupBoxVenda.Text = "Venda";
            // 
            // lbVEstado
            // 
            this.lbVEstado.AutoSize = true;
            this.lbVEstado.Font = new System.Drawing.Font("Microsoft Sans Serif", 13F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbVEstado.Location = new System.Drawing.Point(19, 98);
            this.lbVEstado.Name = "lbVEstado";
            this.lbVEstado.Size = new System.Drawing.Size(0, 22);
            this.lbVEstado.TabIndex = 63;
            // 
            // lbVValor
            // 
            this.lbVValor.AutoSize = true;
            this.lbVValor.Font = new System.Drawing.Font("Microsoft Sans Serif", 13F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbVValor.Location = new System.Drawing.Point(19, 73);
            this.lbVValor.Name = "lbVValor";
            this.lbVValor.Size = new System.Drawing.Size(0, 22);
            this.lbVValor.TabIndex = 62;
            // 
            // lbVData
            // 
            this.lbVData.AutoSize = true;
            this.lbVData.Font = new System.Drawing.Font("Microsoft Sans Serif", 13F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbVData.Location = new System.Drawing.Point(19, 48);
            this.lbVData.Name = "lbVData";
            this.lbVData.Size = new System.Drawing.Size(0, 22);
            this.lbVData.TabIndex = 61;
            // 
            // lbIDVenda
            // 
            this.lbIDVenda.AutoSize = true;
            this.lbIDVenda.Font = new System.Drawing.Font("Microsoft Sans Serif", 15F, System.Drawing.FontStyle.Bold);
            this.lbIDVenda.Location = new System.Drawing.Point(6, 16);
            this.lbIDVenda.Name = "lbIDVenda";
            this.lbIDVenda.Size = new System.Drawing.Size(109, 25);
            this.lbIDVenda.TabIndex = 60;
            this.lbIDVenda.Text = "ID Venda:";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(337, 142);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(173, 15);
            this.label2.TabIndex = 59;
            this.label2.Text = "Dados da Venda do carro:";
            // 
            // comboBoxCombustivel
            // 
            this.comboBoxCombustivel.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.comboBoxCombustivel.FormattingEnabled = true;
            this.comboBoxCombustivel.Items.AddRange(new object[] {
            "Gasolina",
            "Diesel",
            "Eletrico",
            "GPL",
            "Híbrico",
            "Outro"});
            this.comboBoxCombustivel.Location = new System.Drawing.Point(407, 279);
            this.comboBoxCombustivel.Name = "comboBoxCombustivel";
            this.comboBoxCombustivel.Size = new System.Drawing.Size(231, 21);
            this.comboBoxCombustivel.TabIndex = 58;
            // 
            // comboBoxEstado
            // 
            this.comboBoxEstado.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.comboBoxEstado.FormattingEnabled = true;
            this.comboBoxEstado.IntegralHeight = false;
            this.comboBoxEstado.Items.AddRange(new object[] {
            "Novo",
            "Usado"});
            this.comboBoxEstado.Location = new System.Drawing.Point(384, 175);
            this.comboBoxEstado.Name = "comboBoxEstado";
            this.comboBoxEstado.Size = new System.Drawing.Size(121, 21);
            this.comboBoxEstado.TabIndex = 57;
            // 
            // btEVenda
            // 
            this.btEVenda.BackColor = System.Drawing.Color.DarkOrange;
            this.btEVenda.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.btEVenda.Font = new System.Drawing.Font("Microsoft Sans Serif", 8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btEVenda.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.btEVenda.Location = new System.Drawing.Point(502, 403);
            this.btEVenda.Name = "btEVenda";
            this.btEVenda.Size = new System.Drawing.Size(155, 26);
            this.btEVenda.TabIndex = 55;
            this.btEVenda.Text = "Eliminar Venda";
            this.btEVenda.UseVisualStyleBackColor = false;
            this.btEVenda.Click += new System.EventHandler(this.btEVenda_Click);
            // 
            // extrasTextBox
            // 
            this.extrasTextBox.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.vendasBindingSource, "CarroVenda.Extras", true));
            this.extrasTextBox.Location = new System.Drawing.Point(382, 311);
            this.extrasTextBox.Multiline = true;
            this.extrasTextBox.Name = "extrasTextBox";
            this.extrasTextBox.Size = new System.Drawing.Size(266, 72);
            this.extrasTextBox.TabIndex = 53;
            // 
            // vendasBindingSource
            // 
            this.vendasBindingSource.DataSource = typeof(ProjetoStandOficina.Venda);
            // 
            // modeloTextBox
            // 
            this.modeloTextBox.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.vendasBindingSource, "CarroVenda.Modelo", true));
            this.modeloTextBox.Location = new System.Drawing.Point(539, 245);
            this.modeloTextBox.Name = "modeloTextBox";
            this.modeloTextBox.Size = new System.Drawing.Size(99, 20);
            this.modeloTextBox.TabIndex = 52;
            // 
            // marcaTextBox
            // 
            this.marcaTextBox.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.vendasBindingSource, "CarroVenda.Marca", true));
            this.marcaTextBox.Location = new System.Drawing.Point(392, 245);
            this.marcaTextBox.Name = "marcaTextBox";
            this.marcaTextBox.Size = new System.Drawing.Size(88, 20);
            this.marcaTextBox.TabIndex = 51;
            // 
            // numeroChassisTextBox
            // 
            this.numeroChassisTextBox.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.vendasBindingSource, "CarroVenda.NumeroChassis", true));
            this.numeroChassisTextBox.Location = new System.Drawing.Point(426, 210);
            this.numeroChassisTextBox.MaxLength = 17;
            this.numeroChassisTextBox.Name = "numeroChassisTextBox";
            this.numeroChassisTextBox.Size = new System.Drawing.Size(212, 20);
            this.numeroChassisTextBox.TabIndex = 50;
            // 
            // valorTextBox
            // 
            this.valorTextBox.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.vendasBindingSource, "Valor", true));
            this.valorTextBox.Location = new System.Drawing.Point(551, 175);
            this.valorTextBox.Name = "valorTextBox";
            this.valorTextBox.Size = new System.Drawing.Size(87, 20);
            this.valorTextBox.TabIndex = 49;
            // 
            // lbCarroExtras
            // 
            this.lbCarroExtras.AutoSize = true;
            this.lbCarroExtras.Location = new System.Drawing.Point(342, 108);
            this.lbCarroExtras.Name = "lbCarroExtras";
            this.lbCarroExtras.Size = new System.Drawing.Size(0, 13);
            this.lbCarroExtras.TabIndex = 45;
            // 
            // lbCarroCombustivel
            // 
            this.lbCarroCombustivel.AutoSize = true;
            this.lbCarroCombustivel.Location = new System.Drawing.Point(342, 93);
            this.lbCarroCombustivel.Name = "lbCarroCombustivel";
            this.lbCarroCombustivel.Size = new System.Drawing.Size(0, 13);
            this.lbCarroCombustivel.TabIndex = 44;
            // 
            // lbCarroModelo
            // 
            this.lbCarroModelo.AutoSize = true;
            this.lbCarroModelo.Location = new System.Drawing.Point(342, 78);
            this.lbCarroModelo.Name = "lbCarroModelo";
            this.lbCarroModelo.Size = new System.Drawing.Size(0, 13);
            this.lbCarroModelo.TabIndex = 43;
            // 
            // lbCarroNChassi
            // 
            this.lbCarroNChassi.AutoSize = true;
            this.lbCarroNChassi.Location = new System.Drawing.Point(342, 48);
            this.lbCarroNChassi.Name = "lbCarroNChassi";
            this.lbCarroNChassi.Size = new System.Drawing.Size(0, 13);
            this.lbCarroNChassi.TabIndex = 42;
            // 
            // lbCarroMarca
            // 
            this.lbCarroMarca.AutoSize = true;
            this.lbCarroMarca.Location = new System.Drawing.Point(342, 63);
            this.lbCarroMarca.Name = "lbCarroMarca";
            this.lbCarroMarca.Size = new System.Drawing.Size(0, 13);
            this.lbCarroMarca.TabIndex = 41;
            // 
            // lbCarroMatricula
            // 
            this.lbCarroMatricula.AutoSize = true;
            this.lbCarroMatricula.Font = new System.Drawing.Font("Microsoft Sans Serif", 11F, System.Drawing.FontStyle.Bold);
            this.lbCarroMatricula.Location = new System.Drawing.Point(317, 27);
            this.lbCarroMatricula.Name = "lbCarroMatricula";
            this.lbCarroMatricula.Size = new System.Drawing.Size(116, 18);
            this.lbCarroMatricula.TabIndex = 40;
            this.lbCarroMatricula.Text = "Carro Vendido";
            // 
            // btnIVenda
            // 
            this.btnIVenda.BackColor = System.Drawing.Color.DarkOrange;
            this.btnIVenda.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.btnIVenda.Font = new System.Drawing.Font("Microsoft Sans Serif", 8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnIVenda.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.btnIVenda.Location = new System.Drawing.Point(336, 403);
            this.btnIVenda.Name = "btnIVenda";
            this.btnIVenda.Size = new System.Drawing.Size(160, 26);
            this.btnIVenda.TabIndex = 8;
            this.btnIVenda.Text = "Inserir Venda";
            this.btnIVenda.UseVisualStyleBackColor = false;
            this.btnIVenda.Click += new System.EventHandler(this.btnIVenda_Click);
            // 
            // listBoxVenda
            // 
            this.listBoxVenda.FormattingEnabled = true;
            this.listBoxVenda.Location = new System.Drawing.Point(9, 165);
            this.listBoxVenda.Name = "listBoxVenda";
            this.listBoxVenda.Size = new System.Drawing.Size(317, 264);
            this.listBoxVenda.TabIndex = 6;
            this.listBoxVenda.SelectedIndexChanged += new System.EventHandler(this.listBoxVenda_SelectedIndexChanged);
            // 
            // FormVenda
            // 
            this.AllowDrop = true;
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.AutoScroll = true;
            this.AutoSize = true;
            this.BackColor = System.Drawing.SystemColors.ControlLightLight;
            this.ClientSize = new System.Drawing.Size(884, 611);
            this.ControlBox = false;
            this.Controls.Add(this.groupBoxVenda);
            this.Controls.Add(this.lbClienteContacto);
            this.Controls.Add(this.lbClienteMorada);
            this.Controls.Add(this.lbClienteNif);
            this.Controls.Add(this.lbClienteNome);
            this.Controls.Add(this.groupBox1);
            this.Controls.Add(this.toolStrip1);
            this.Name = "FormVenda";
            this.Text = "Venda";
            this.Load += new System.EventHandler(this.FormVenda_Load);
            this.toolStrip1.ResumeLayout(false);
            this.toolStrip1.PerformLayout();
            this.groupBox1.ResumeLayout(false);
            this.groupBoxVenda.ResumeLayout(false);
            this.groupBoxVenda.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.vendasBindingSource)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.ToolStrip toolStrip1;
        private System.Windows.Forms.ToolStripLabel sairToolStripMenuItem;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.ListBox listBoxCliente;
        private System.Windows.Forms.Label lbClienteContacto;
        private System.Windows.Forms.Label lbClienteMorada;
        private System.Windows.Forms.Label lbClienteNif;
        private System.Windows.Forms.Label lbClienteNome;
        private System.Windows.Forms.GroupBox groupBoxVenda;
        private System.Windows.Forms.Button btnIVenda;
        private System.Windows.Forms.ListBox listBoxVenda;
        private System.Windows.Forms.Label lbCarroExtras;
        private System.Windows.Forms.Label lbCarroCombustivel;
        private System.Windows.Forms.Label lbCarroModelo;
        private System.Windows.Forms.Label lbCarroNChassi;
        private System.Windows.Forms.Label lbCarroMarca;
        private System.Windows.Forms.Label lbCarroMatricula;
        private System.Windows.Forms.Button btEVenda;
        private System.Windows.Forms.BindingSource vendasBindingSource;
        private System.Windows.Forms.TextBox extrasTextBox;
        private System.Windows.Forms.TextBox modeloTextBox;
        private System.Windows.Forms.TextBox marcaTextBox;
        private System.Windows.Forms.TextBox numeroChassisTextBox;
        private System.Windows.Forms.TextBox valorTextBox;
        private System.Windows.Forms.ComboBox comboBoxEstado;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.ComboBox comboBoxCombustivel;
        private System.Windows.Forms.Label lbVEstado;
        private System.Windows.Forms.Label lbVValor;
        private System.Windows.Forms.Label lbVData;
        private System.Windows.Forms.Label lbIDVenda;
    }
}