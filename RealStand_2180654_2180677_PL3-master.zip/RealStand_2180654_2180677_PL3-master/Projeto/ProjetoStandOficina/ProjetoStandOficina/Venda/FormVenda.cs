﻿using System;
using System.Linq;
using System.Windows.Forms;

namespace ProjetoStandOficina
{
    public partial class FormVenda : Form
    {
        private BaseDadosOficinaContainer basedadosO;
        public FormVenda()
        {
            InitializeComponent();
        }
        private void FormVenda_Load(object sender, EventArgs e)
        {
            basedadosO = new BaseDadosOficinaContainer();
            AtualizarListaCliente();
       
        }

        #region "Atulizar listas"
        //Lista cliente
        private void AtualizarListaCliente()
        {
            listBoxCliente.DataSource = basedadosO.Clientes.ToList<Cliente>();
        }
        //lista venda
        private void AtualizarListaVenda()
        {
            Cliente clienteSelecionado = listBoxCliente.SelectedItem as Cliente;
            int pos = listBoxVenda.SelectedIndex; //guardar posição do index
            listBoxVenda.DataSource = null;
            if (clienteSelecionado == null) // se não existir clientes sai
            {
                
                groupBoxVenda.Enabled = false;
                //carro
                lbCarroMatricula.Visible = false;
                lbCarroNChassi.Visible = false;
                lbCarroMarca.Visible = false;
                lbCarroModelo.Visible = false;
                lbCarroCombustivel.Visible = false;

                //venda
                lbIDVenda.Text = "Selecione um cliente e crie/selecione uma venda";
                lbVData.Visible = false;
                lbVValor.Visible = false;
                lbVEstado.Visible = false;
                return;
            }

            listBoxVenda.DataSource = clienteSelecionado.Vendas.ToList(); //atualiza lista
            if (listBoxVenda.Items.Count > 0) //se o numero de elementos da lista for maior que 0
            {
                if (pos < listBoxVenda.Items.Count) //se a posição do index for menor que o numero de elementos na lista
                {
                    listBoxVenda.SelectedIndex = pos; //seleciona a posição               
                }
                else
                {
                    listBoxVenda.SelectedIndex = listBoxVenda.Items.Count - 1; //se não seleciona a posição anterior
                }
            }

        }

        #endregion
        #region "Cliente"
        //Selecionar uma cliente
        private void listBoxCliente_SelectedIndexChanged(object sender, EventArgs e)
        {
            //sempre que um cliente é selecionado a seleção muda de imediato
            Cliente clienteSelecionado = listBoxCliente.SelectedItem as Cliente;

            //verifica se existe cliente, se não existir sai
            if (clienteSelecionado == null)
            {
                groupBoxVenda.Enabled = false;
                MessageBox.Show("Não existe nenhum Cliente selecionado!Infromção:Caso não tenha nenhum crie.","Cliente!");
                return;
            }
            //Caso existir          
            groupBoxVenda.Enabled = true;

            //atualiza as labels com nome,nif,morada,Contacto do cliente
            lbClienteNome.Text = "Nome:" + clienteSelecionado.Nome;
            lbClienteNif.Text = "Nif:" + clienteSelecionado.NIF;
            lbClienteMorada.Text = "Morada:" + clienteSelecionado.Morada;
            lbClienteContacto.Text = "Contacto:" + clienteSelecionado.Contacto;

            //atualiza a lista modo a mostrar a lista referente a esse cliente
            AtualizarListaVenda();

        }
        #endregion
        #region "Venda"

        //Selecionar uma venda
        private void listBoxVenda_SelectedIndexChanged(object sender, EventArgs e)
        {
            Venda vendaSelecionada = listBoxVenda.SelectedItem as Venda;

            if (listBoxVenda.SelectedIndex != -1)
            {
                //meter visivel as labels dos carroVenda e da venda
                lbCarroMatricula.Visible = true;
                lbCarroNChassi.Visible = true;
                lbCarroMarca.Visible = true;
                lbCarroModelo.Visible = true;
                lbCarroCombustivel.Visible = true;
                lbCarroMarca.Visible = true;

                lbIDVenda.Visible =true;
                lbVData.Visible = true;
                lbVValor.Visible = true;
                lbVEstado.Visible = true;


                // Mostrar os dados nas labels dos carros e da venda
                //carro
                lbCarroNChassi.Text = "Nº de Chassi:" + vendaSelecionada.CarroVenda.NumeroChassis;
                lbCarroMarca.Text = "Marca:" + vendaSelecionada.CarroVenda.Marca;
                lbCarroModelo.Text = "Modelo:" + vendaSelecionada.CarroVenda.Modelo;
                lbCarroCombustivel.Text = "Combustivel:" + vendaSelecionada.CarroVenda.Combustivel;
                lbCarroExtras.Text = "Extras" + vendaSelecionada.CarroVenda.Extras;
                //venda
                lbIDVenda.Text = "ID Venda:"+vendaSelecionada.IdVenda;
                lbVData.Text = "Data de Venda:"+vendaSelecionada.Data;
                lbVValor.Text = "Valor da Venda:"+vendaSelecionada.Valor;
                lbVEstado.Text = "Estado do carro:"+vendaSelecionada.Estado;


            }
            else
            { 
                //Esconder os dados do carro selecionado nas label's            

                //carro
                lbCarroMatricula.Visible = false;
                lbCarroNChassi.Visible = false;
                lbCarroMarca.Visible = false;
                lbCarroModelo.Visible = false;
                lbCarroCombustivel.Visible = false;
                lbCarroExtras.Visible = false;
                //venda
                lbIDVenda.Text = "Selecione um cliente e crie/selecione a sua venda";
                lbVData.Visible = false;
                lbVValor.Visible = false;
                lbVEstado.Visible = false;

            }
        }
        //Botão inserir Venda
        private void btnIVenda_Click(object sender, EventArgs e)
        {
            //Dados do cliente selecionado
            Cliente clienteSelecionado = listBoxCliente.SelectedItem as Cliente;
            //se não existir nenhum serviço. erro: "Não existe nenhum serviço!"
            if (clienteSelecionado == null)
            {
                MessageBox.Show("Não existe nenhum Cliente selecionado!Infromção:Caso não tenha nenhum crie.");
                return;
            }
            //verificar se está tudo preenchido 
            if (valorTextBox.Text == "" || comboBoxEstado.Text == "")
            {
                MessageBox.Show("Preencha todos os campos da venda antes efectuar a Venda!");
                return;
            }
            if (marcaTextBox.Text==""|| modeloTextBox.Text==""|| numeroChassisTextBox.Text==""||comboBoxCombustivel.Text==""||extrasTextBox.Text=="")
            {
                MessageBox.Show("Preencha todos os campos do carro antes de fazer a Venda!");
                return;
            }
            //se existir cria Venda
            Venda venda = new Venda();
            CarroVenda carroVenda = new CarroVenda();

            //CAMPOS
            //DATA E ESTADO
            venda.Data = Convert.ToDateTime(DateTime.Now.ToLongTimeString());
            venda.Estado = comboBoxEstado.Text;
           

            //VALOR
            //Variavel para retorno da conversão 
            double valorr;
            //Utilização do TryParse, para validação do objeto. Verificamos se o mesmo é double    
            if (double.TryParse(valorTextBox.Text, out valorr))
            {
                venda.Valor = Convert.ToDouble(valorTextBox.Text);
                
            }
            else
            {
                MessageBox.Show("Tem de introduzir os dados corretamentos no Valor. Informação:Tem de introduzir numeros.");
                return;
            }
            //Custos da impresa 
            switch (comboBoxEstado.Text)
            {
                case "Novo":                  
                    venda.Valor += 1500;
                    break;

                case "Usado":
                    venda.Valor += 500;
                    break;
            }
            //NCHASSI, MARCA,MODELO,COMBUSTIVEL E EXTRAS
       
                //Verificar se o nº de chassi já existe
                foreach (CarroVenda carroVendaverificar in basedadosO.Carros.OfType<CarroVenda>())
                {
                
                    if (carroVendaverificar.NumeroChassis == Convert.ToString(numeroChassisTextBox.Text))
                    {
                        MessageBox.Show("Este Carro já foi inserido verifique Nº de Chassi pois já existe.");
                        return;
                    }
                    else
                    {
                        carroVenda.NumeroChassis = numeroChassisTextBox.Text;
                    
                    }
                }
            
            
            carroVenda.Marca = marcaTextBox.Text;
            carroVenda.Modelo = modeloTextBox.Text;
            carroVenda.Combustivel = comboBoxCombustivel.Text;
            carroVenda.Extras = extrasTextBox.Text;

            //Add a venda e o carro
            clienteSelecionado.Vendas.Add(venda);

            carroVenda.Venda = venda;
            venda.CarroVenda = carroVenda;
            //salvar na base de dados
            basedadosO.SaveChanges();
            //Menssagem de sucesso
            MessageBox.Show("Venda feita com sucesso!","Venda!");
            //atualiza as listas
            AtualizarListaVenda();
        }

        //botão eliminar
        private void btEVenda_Click(object sender, EventArgs e)
        {

            Venda vendaSelecionada = listBoxVenda.SelectedItem as Venda;
            CarroVenda carroVendaSelecionado = vendaSelecionada.CarroVenda;

            if (MessageBox.Show( "Deseja eliminar a Venda?", "Eliminar Venda!", MessageBoxButtons.YesNo) == DialogResult.Yes)
            {
                try
                {
                    //remove a venda e o carro da venda
                    basedadosO.Vendas.Remove(vendaSelecionada);
                    basedadosO.Carros.Remove(carroVendaSelecionado);
                    //salva na base de dados
                    basedadosO.SaveChanges();
                    //mensagem que foi eliminado
                    MessageBox.Show("Este Venda foi eliminada com sucesso.", "Eliminar Venda!");

                   }
                   catch (Exception)
                   {
                    //mensagem de erro
                    MessageBox.Show("Erro ao eliminar, tente outra vez!", "Eliminar Venda!");
                   }       
                //Atualiza a lista venda
                AtualizarListaVenda();
            }
            else
            {
                MessageBox.Show("Este Venda não foi eliminada.", "Eliminar Venda!");
            }
        }

        #endregion
        //botão sair
        private void sairToolStripMenuItem_Click(object sender, EventArgs e)
        {
            if (MessageBox.Show("Deseja sair da Janela das Vendas?", "Sair!", MessageBoxButtons.YesNo) == DialogResult.Yes)
            {
                basedadosO.Dispose();
                this.Close();
            }
        }
    }
}
