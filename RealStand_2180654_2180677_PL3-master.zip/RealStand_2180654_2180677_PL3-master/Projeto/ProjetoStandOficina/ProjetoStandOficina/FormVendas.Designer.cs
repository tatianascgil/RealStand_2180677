﻿namespace ProjetoStandOficina
{
    partial class FormVendas
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.listBoxCliente = new System.Windows.Forms.ListBox();
            this.btnIClientes = new System.Windows.Forms.Button();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.listBoxCarros = new System.Windows.Forms.ListBox();
            this.btnICarro = new System.Windows.Forms.Button();
            this.groupBox3 = new System.Windows.Forms.GroupBox();
            this.listBoxVendas = new System.Windows.Forms.ListBox();
            this.btnIVendas = new System.Windows.Forms.Button();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.groupBox1.SuspendLayout();
            this.groupBox2.SuspendLayout();
            this.groupBox3.SuspendLayout();
            this.SuspendLayout();
            // 
            // listBoxCliente
            // 
            this.listBoxCliente.FormattingEnabled = true;
            this.listBoxCliente.Location = new System.Drawing.Point(6, 19);
            this.listBoxCliente.Name = "listBoxCliente";
            this.listBoxCliente.Size = new System.Drawing.Size(262, 498);
            this.listBoxCliente.TabIndex = 1;
            // 
            // btnIClientes
            // 
            this.btnIClientes.Location = new System.Drawing.Point(150, 519);
            this.btnIClientes.Name = "btnIClientes";
            this.btnIClientes.Size = new System.Drawing.Size(117, 33);
            this.btnIClientes.TabIndex = 2;
            this.btnIClientes.Text = "Inserir Cliente";
            this.btnIClientes.UseVisualStyleBackColor = true;
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.listBoxCliente);
            this.groupBox1.Controls.Add(this.btnIClientes);
            this.groupBox1.Location = new System.Drawing.Point(12, 12);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(273, 570);
            this.groupBox1.TabIndex = 3;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "Selecione um Cliente";
            // 
            // groupBox2
            // 
            this.groupBox2.Controls.Add(this.btnICarro);
            this.groupBox2.Controls.Add(this.listBoxCarros);
            this.groupBox2.Location = new System.Drawing.Point(291, 139);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Size = new System.Drawing.Size(315, 443);
            this.groupBox2.TabIndex = 4;
            this.groupBox2.TabStop = false;
            this.groupBox2.Text = "Carros";
            // 
            // listBoxCarros
            // 
            this.listBoxCarros.FormattingEnabled = true;
            this.listBoxCarros.Location = new System.Drawing.Point(12, 18);
            this.listBoxCarros.Name = "listBoxCarros";
            this.listBoxCarros.Size = new System.Drawing.Size(303, 368);
            this.listBoxCarros.TabIndex = 0;
            // 
            // btnICarro
            // 
            this.btnICarro.Location = new System.Drawing.Point(192, 392);
            this.btnICarro.Name = "btnICarro";
            this.btnICarro.Size = new System.Drawing.Size(117, 33);
            this.btnICarro.TabIndex = 1;
            this.btnICarro.Text = "Inserir Carro";
            this.btnICarro.UseVisualStyleBackColor = true;
            // 
            // groupBox3
            // 
            this.groupBox3.Controls.Add(this.btnIVendas);
            this.groupBox3.Controls.Add(this.listBoxVendas);
            this.groupBox3.Location = new System.Drawing.Point(632, 139);
            this.groupBox3.Name = "groupBox3";
            this.groupBox3.Size = new System.Drawing.Size(315, 443);
            this.groupBox3.TabIndex = 5;
            this.groupBox3.TabStop = false;
            this.groupBox3.Text = "Vendas";
            // 
            // listBoxVendas
            // 
            this.listBoxVendas.FormattingEnabled = true;
            this.listBoxVendas.Location = new System.Drawing.Point(12, 18);
            this.listBoxVendas.Name = "listBoxVendas";
            this.listBoxVendas.Size = new System.Drawing.Size(303, 368);
            this.listBoxVendas.TabIndex = 0;
            // 
            // btnIVendas
            // 
            this.btnIVendas.Location = new System.Drawing.Point(186, 396);
            this.btnIVendas.Name = "btnIVendas";
            this.btnIVendas.Size = new System.Drawing.Size(117, 33);
            this.btnIVendas.TabIndex = 1;
            this.btnIVendas.Text = "Inserir Vendas";
            this.btnIVendas.UseVisualStyleBackColor = true;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(342, 54);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(122, 13);
            this.label1.TabIndex = 6;
            this.label1.Text = "Sem cliente selecionado";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(886, 54);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(61, 13);
            this.label2.TabIndex = 7;
            this.label2.Text = "Valor Total:";
            // 
            // FormVendas
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1243, 594);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.groupBox3);
            this.Controls.Add(this.groupBox2);
            this.Controls.Add(this.groupBox1);
            this.Name = "FormVendas";
            this.Text = "FormVendas";
            this.groupBox1.ResumeLayout(false);
            this.groupBox2.ResumeLayout(false);
            this.groupBox3.ResumeLayout(false);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion
        private System.Windows.Forms.ListBox listBoxCliente;
        private System.Windows.Forms.Button btnIClientes;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.GroupBox groupBox2;
        private System.Windows.Forms.Button btnICarro;
        private System.Windows.Forms.ListBox listBoxCarros;
        private System.Windows.Forms.GroupBox groupBox3;
        private System.Windows.Forms.Button btnIVendas;
        private System.Windows.Forms.ListBox listBoxVendas;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
    }
}