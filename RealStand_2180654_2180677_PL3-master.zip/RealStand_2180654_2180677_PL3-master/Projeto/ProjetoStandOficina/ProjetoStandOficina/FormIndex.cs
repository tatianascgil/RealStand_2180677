﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace ProjetoStandOficina
{
    public partial class FormIndex : Form
    {
        public FormIndex()
        {
            InitializeComponent();
        }

        //botão gestão cliente
        private void btnGClientes_Click(object sender, EventArgs e)
        {
            FormCliente frmcliente = new FormCliente();
            frmcliente.ShowDialog();

        }
        //botão gestão Oficina
        private void btnGOficina_Click(object sender, EventArgs e)
        {
            FormOficina frmOficina = new FormOficina();
            frmOficina.ShowDialog();
        }
        //botão gestão Alugueres
        private void btnAluguer_Click(object sender, EventArgs e)
        {
            FormAluguer frmAluguer = new FormAluguer();
            frmAluguer.ShowDialog();
        }
        //botão gestão Vendas
        private void btnGVendas_Click(object sender, EventArgs e)
        {
            FormVenda frmVenda = new FormVenda();
            frmVenda.ShowDialog();
        }
        //botão sair
        private void btnSair_Click(object sender, EventArgs e)
        {
            if (MessageBox.Show("Deseja sair do Programa?", "Sair!", MessageBoxButtons.YesNo) == DialogResult.Yes)
            {
                this.Close();
            }
        }
    }
} 
