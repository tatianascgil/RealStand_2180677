﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.Entity;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace ProjetoStandOficina
{
    public partial class FormCliente : Form
    {
        private BaseDadosOficinaContainer basedadosO;

        public FormCliente()
        {
            InitializeComponent();

            basedadosO = new BaseDadosOficinaContainer();

            (from cliente in basedadosO.Clientes
             orderby cliente.Nome
             select cliente).Load();
            //atualiza a lista dos clientes
            clienteBindingSource.DataSource = basedadosO.Clientes.Local.ToBindingList();
            //botão guardar bloqueado
            clienteBindingNavigatorSaveItem.Enabled = false;
        }
        //botão guardar
        private void clienteBindingNavigatorSaveItem_Click(object sender, EventArgs e)
        {
            //verifica se estão todos os campos preenchidos
            if (nomeTextBox.Text==""||nIFTextBox.Text==""||moradaTextBox.Text==""||maskedTextBox1.Text=="")
            {
                MessageBox.Show("Preencha todos os campos do cliente antes efectuar a sua Inscrição no programa!","Cliente!");
                return;
            }


            /* 
            foreach (Cliente clienteverificar in basedadosO.Clientes)
            {
             
                if ((clienteverificar.NIF == nIFTextBox.Text))
                {
                    MessageBox.Show("Este Cliente já foi inserido, verifique o NIF que introduziu pois já existe.");
                    return;
                }
                else
                {
                    cliente.NIF = nIFTextBox.Text;
                    
                }

            }
            */
            //é obrigatorio ter sempre o client admin inscrito
            clienteBindingSource.MoveFirst();

            //salva na base de dados
            basedadosO.SaveChanges();
            //mensagem de informação
            MessageBox.Show("Guardado com sucesso!");

            //para ficar bem funcional meter este botoes nestes estados
            clienteBindingNavigatorSaveItem.Enabled = false;
            bindingNavigatorAddNewItem.Enabled = true;
            bindingNavigatorDeleteItem.Enabled = true;

        }
        //botão adicionar
        private void bindingNavigatorAddNewItem_Click(object sender, EventArgs e)
        {
            //mensagem de informação
            MessageBox.Show("Tem de guardar obrigatorimente depois de todos os campos preenchidos!");
            //para ficar bem funcional meter este botoes nestes estados
            bindingNavigatorDeleteItem.Enabled = false;
            bindingNavigatorAddNewItem.Enabled = false;
            clienteBindingNavigatorSaveItem.Enabled = true;
        }
        //botão eliminar
        private void bindingNavigatorDeleteItem_Click(object sender, EventArgs e)
        {
            //mensagem de informação
            MessageBox.Show("Tem de guardar obrigatorimente, pois caso não o faça não vai ser nada eliminado!");
            //para ficar bem funcional meter este botoes nestes estados
            bindingNavigatorAddNewItem.Enabled = false;
            bindingNavigatorDeleteItem.Enabled = false;
            clienteBindingNavigatorSaveItem.Enabled = true;
        }
        #region "filtrar"
        //flitrar
        private void btnFiltrar_Click(object sender, EventArgs e)
        {
            if (tbFiltrar.Text.Length > 0)
            {
                bindingNavigatorAddNewItem.Enabled = false;
                basedadosO.Dispose();
                basedadosO = new BaseDadosOficinaContainer();
                (from cliente in basedadosO.Clientes
                 where cliente.Nome.ToUpper().Contains(tbFiltrar.Text.ToUpper())
                 orderby cliente.Nome
                 select cliente).ToList();
                clienteBindingSource.DataSource = basedadosO.Clientes.Local.ToBindingList();
            }
            else
            {
                bindingNavigatorAddNewItem.Enabled = true;
                basedadosO.Dispose();
                basedadosO = new BaseDadosOficinaContainer();
                (from cliente in basedadosO.Clientes
                 orderby cliente.Nome
                 select cliente).Load();
                clienteBindingSource.DataSource = basedadosO.Clientes.Local.ToBindingList();
            }
        }
        #endregion
        #region "Faturação"
        //criar pasta no ambiente de trabalho
        private void faturar_Click(object sender, EventArgs e)
        {
            Cliente clienteSelecionado = (Cliente)clienteDataGridView.CurrentRow.DataBoundItem;
            if (clienteSelecionado == null)
            {
                MessageBox.Show("Não tem nenhum cliente selecionado!");
                return;
            }

            string pathDesktop = Environment.GetFolderPath(Environment.SpecialFolder.Desktop);
            string pathDesktopPastaClientes = pathDesktop + @"\Clientes";
            string pathPastaClienteComFicheiroCliente = pathDesktopPastaClientes + @"\Cliente_" + clienteSelecionado.NIF;
            string pathParaFicheiroDoCliente = pathPastaClienteComFicheiroCliente + @"\Cliente_" + clienteSelecionado.Nome + ".txt";
            try
            {
                if (Directory.Exists(pathPastaClienteComFicheiroCliente))
                {
                    WriteStuff(clienteSelecionado, pathParaFicheiroDoCliente);
                }
                else
                {
                    DirectoryInfo directoryInfo = Directory.CreateDirectory(pathPastaClienteComFicheiroCliente);
                    WriteStuff(clienteSelecionado, pathParaFicheiroDoCliente);
                }

                MessageBox.Show("Ficha de Cliente Exportada para o Ambiente de Trabalho");
            }
            catch (Exception err)
            {
                Console.WriteLine(err.Message);
            }

        }
        //função que escreve o documento de texto 
        private void WriteStuff(Cliente clienteSelecionado, String pathParaFicheiroDoCliente)
        {
            TextWriter tw;
            tw = new StreamWriter(pathParaFicheiroDoCliente);
            tw.WriteLine("CLIENTE:\t" + clienteSelecionado.Nome);
            tw.WriteLine("NIF:\t\t" + clienteSelecionado.NIF);
            tw.WriteLine("MORADA:\t\t" + clienteSelecionado.Morada);
            tw.WriteLine("CONTACTO:\t" + clienteSelecionado.Contacto);
            tw.WriteLine(Environment.NewLine + Environment.NewLine + "----------------------------------------------------------------------");
            tw.WriteLine(Environment.NewLine + "\t\t\t\tOFICINA");
            tw.WriteLine(Environment.NewLine + "----------------------------------------------------------------------");

            foreach (CarroOficina carroOficinaSelecionado in clienteSelecionado.CarrosOficina.ToList())
            {
                tw.WriteLine("\tMarca:\t\t\t\t\t" + carroOficinaSelecionado.Marca + "\tModelo:" + carroOficinaSelecionado.Modelo);
                tw.WriteLine("\tMatricula:\t\t\t\t" + carroOficinaSelecionado.Matricula);
                tw.WriteLine("\tNúmero de Chassis:\t\t\t" + carroOficinaSelecionado.NumeroChassis);
                tw.WriteLine("\tTipo de Carro:\t\t\t\t" + carroOficinaSelecionado.Combustivel);
                tw.WriteLine("\tKilometragem:\t\t\t\t" + carroOficinaSelecionado.Kms);
                foreach (Servico servicoSelecionado in carroOficinaSelecionado.Servicos.ToList())
                {
                    tw.WriteLine("\tServiço no Carro");
                    tw.WriteLine("\t\tTipo de Serviço:\t\t" + servicoSelecionado.Tipo);
                    tw.WriteLine("\t\tData de Entrada do Carro:\t" + servicoSelecionado.DataEntrada);
                    tw.WriteLine("\t\tData de Saída do Carro:\t\t" + servicoSelecionado.DataSaida);
                    tw.WriteLine("\t\tTotal no Serviço:\t\t" + servicoSelecionado.Total.ToString() + " €");
                    tw.WriteLine(Environment.NewLine + "\t\t-Parcelas do Serviço");
                    foreach (Parcela parcelaSelecionada in servicoSelecionado.Parcelas.ToList())
                    {
                        tw.WriteLine("\t\t\tDescrição:\t\t" + parcelaSelecionada.Descricao);
                        tw.WriteLine("\t\t\tValor:\t\t\t" + parcelaSelecionada.Valor + " €");
                    }
                }
                tw.WriteLine("\t---------------------------------------------------");
            }

            tw.WriteLine(Environment.NewLine + Environment.NewLine + "----------------------------------------------------------------------");
            tw.WriteLine(Environment.NewLine + "\t\t\t\tVENDAS");
            tw.WriteLine(Environment.NewLine + "----------------------------------------------------------------------");
            foreach (Venda venda in clienteSelecionado.Vendas.ToList())
            {
                tw.WriteLine("\tData da Venda:\t\t\t\t" + venda.Data);
                tw.WriteLine("\tCarro Vendido\t\t\t");
                tw.WriteLine("\t\tMarca:\t\t\t\t" + venda.CarroVenda.Marca + " " + venda.CarroVenda.Modelo);
                tw.WriteLine("\t\tNúmero de Chassis:\t\t" + venda.CarroVenda.NumeroChassis);
                tw.WriteLine("\t\tTipo de Carro:\t\t\t" + venda.CarroVenda.Combustivel);
                tw.WriteLine("\t\tExtras do Carro:\t\t" + venda.CarroVenda.Extras);
                tw.WriteLine("\tEstado:\t\t\t\t\t" + venda.Estado);
                tw.WriteLine("\tValor da Venda:\t\t\t" + venda.Valor + " € (taxa da empresa incluida)");
                tw.WriteLine("\t-----------------------------------------------------------");
            }
            tw.WriteLine(Environment.NewLine + Environment.NewLine + "----------------------------------------------------------------------");
            tw.WriteLine(Environment.NewLine + "\t\t\t\tALUGUERES");
            tw.WriteLine(Environment.NewLine + "----------------------------------------------------------------------");
            foreach (Aluguer aluguer in clienteSelecionado.Alugueres.ToList())
            {
                tw.WriteLine("\tData Inicial:\t\t\t\t" + aluguer.DataInicio);
                tw.WriteLine("\tData Final:\t\t\t\t" + aluguer.DataFim);
                tw.WriteLine("\tCarro Alugado");
                tw.WriteLine("\t\tMarca:\t\t\t\t" + aluguer.CarroAluguer.Marca + " " + aluguer.CarroAluguer.Modelo);
                tw.WriteLine("\t\tMatricula:\t\t\t" + aluguer.CarroAluguer.Matricula);
                tw.WriteLine("\t\tNúmero de Chassis:\t\t" + aluguer.CarroAluguer.NumeroChassis);
                tw.WriteLine("\t\tTipo de Carro:\t\t\t" + aluguer.CarroAluguer.Combustivel);
                tw.WriteLine("\t\tEstado do Carro:\t\t" + aluguer.CarroAluguer.Estado);
                tw.WriteLine("\tValor de Aluguer:\t\t" + aluguer.Valor + " €(taxa da empresa incluida)");
                tw.WriteLine("\t-----------------------------------------------------------");
            }
            tw.WriteLine(Environment.NewLine + Environment.NewLine + "----------------------------------------------------------------------");
            tw.Close();

            //todas as informações do cliente, incluindo arranjo na oficina e os respetivos serviços e parcelas
            //os carros que comprou ou alugou
        }
        #endregion
        //botão sair
        private void sairToolStripMenuItem_Click(object sender, EventArgs e)
        {
            if (MessageBox.Show("Deseja sair da Janela das Cliente?", "Sair!", MessageBoxButtons.YesNo) == DialogResult.Yes)
            {
                basedadosO.Dispose();
                this.Close();
            }
        }

        
    }
}
