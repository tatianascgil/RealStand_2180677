﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace ProjetoStandOficina
{
    public partial class formCarroOficina : Form
    {
        private BaseDadosOfinaContainer badedadosO;
        private Cliente clienteSelecionado;

        public formCarroOficina(Cliente clienteSelecionado, BaseDadosOfinaContainer badedadosO)
        {
           
            InitializeComponent();
            this.clienteSelecionado= clienteSelecionado;
            this.badedadosO = badedadosO;
            
        }

        

        private void btnICarro_Click(object sender, EventArgs e)
        {
            //gera um carro com caratecristicas da oficina novo 
            CarroOficina carroOficina = new CarroOficina();

            //campos
            carroOficina.Kms = kmsTextBox.Text;
            carroOficina.Combustivel = combustivelTextBox.Text;
            carroOficina.Marca = marcaTextBox.Text;
            carroOficina.Modelo = modeloTextBox.Text;
            carroOficina.NumeroChassis = numeroChassisTextBox.Text;
            carroOficina.Matricula = matriculaTextBox.Text;

            
            clienteSelecionado.CarroOficina.Add(carroOficina);

            //salvar na base de dados o novo carroOficina
            badedadosO.SaveChanges();
            this.Close();

        }
    }
}
