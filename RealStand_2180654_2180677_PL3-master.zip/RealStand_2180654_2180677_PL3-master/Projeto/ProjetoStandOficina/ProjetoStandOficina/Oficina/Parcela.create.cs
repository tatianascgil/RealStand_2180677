﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ProjetoStandOficina
{
    public partial class Parcela
    {
        public void IncrementarValorTotal(float valorProduto)
        {
            this.Valor += valorProduto;
        }

        public void DecrementarValorTotal(float valorProduto)
        {
            this.Valor = Valor - valorProduto;
        } 

        public override string ToString()
        {
            return "Valor:"+Valor+"Descrição:" + Descricao;
        }
    }
}
