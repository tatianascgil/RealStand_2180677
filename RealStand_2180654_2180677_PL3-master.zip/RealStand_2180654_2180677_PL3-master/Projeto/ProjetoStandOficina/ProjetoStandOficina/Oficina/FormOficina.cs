﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace ProjetoStandOficina
{
    public partial class FormOficina : Form
    {
        private BaseDadosOficinaContainer basedadosO;
        public FormOficina()
        {
            InitializeComponent();
        }

        private void FormOficina_Load(object sender, EventArgs e)
        {
            //FormOficina formOficina = new FormOficina();
            // this.formOficina = new Size(140, 480);

            basedadosO = new BaseDadosOficinaContainer();
            AtualizarListaCliente();
        }

       

        #region "Clientes"
        // selecionar o cliente 
        private void listBoxCliente_SelectedIndexChanged(object sender, EventArgs e)
        {
            //sempre que um cliente é selecionado a seleção muda de imediato
            Cliente clienteSelecionado = listBoxCliente.SelectedItem as Cliente;

            //verifica se existe cliente, se não existir sai
            if (clienteSelecionado == null)
            {
                //Não mexer nas outras propriadades
                groupBox2.Enabled = false;
                groupBox3.Enabled = false;
                groupBox4.Enabled = false;
              

                MessageBox.Show("Não existe nenhum Cliente selecionado!Infromção:Caso não tenha nenhum crie.");
                return;
            }
            //Caso existir  
            //desbloqueia a parte do carro
            groupBox2.Enabled = true;
            //atualiza as labels com nome,nif,morada,Contacto do cliente
            lbClienteNome.Text ="Nome:"+ clienteSelecionado.Nome;
            lbClienteNif.Text = "NIF:"+ clienteSelecionado.NIF;
            lbClienteMorada.Text = "Morada:"+ clienteSelecionado.Morada;
            lbClienteContacto.Text ="Concacto:"+ clienteSelecionado.Contacto;

            //atualiza a lista modo a mostrar a lista referente a esse cliente
            AtualizarListaCarro();


        }

        #endregion

        #region "Carros Oficina"
        //selecionar o carro
        private void listBoxCarro_SelectedIndexChanged(object sender, EventArgs e)
        {
            //sempre que um cliente é selecionado a seleção muda de imediato
            CarroOficina carroSelecionado = listBoxCarro.SelectedItem as CarroOficina;

            if (listBoxCarro.SelectedIndex != -1)
            {
                lbCarroMatricula.Visible = true;
                lbCarroNChassi.Visible = true;
                lbCarroMarca.Visible = true;
                lbCarroModelo.Visible = true;
                lbCarroCombustivel.Visible = true;
                lbCarroKms.Visible = true;

                lbCarroMatricula.Text = "Matricula do Carro:" + carroSelecionado.Matricula;
                lbCarroNChassi.Text = "Nº de Chassi:" + carroSelecionado.NumeroChassis;
                lbCarroMarca.Text = "Marca:" + carroSelecionado.Marca;
                lbCarroModelo.Text = "Modelo:" + carroSelecionado.Modelo;
                lbCarroCombustivel.Text = "Combustivel:" + carroSelecionado.Combustivel;
                lbCarroKms.Text = "Kms:" + carroSelecionado.Kms;
                AtualizarListaServico();
            }
           

        }
        private void btnICarro_Click(object sender, EventArgs e)
        {
            Cliente clienteSelecionado = listBoxCliente.SelectedItem as Cliente;

            //se não existir nenhum cliente erro: "Não existe nenhum cliente!"
            if (clienteSelecionado == null)
            {
                MessageBox.Show("Não existe nenhum Cliente selecionado!");
                return;
            }

            //vai para outro form para introduzir os dados
            formCarroOficina frmcarro = new formCarroOficina(clienteSelecionado, basedadosO);           
            frmcarro.FormClosed += new FormClosedEventHandler(formclosecarro);
            frmcarro.ShowDialog();


        }

        //Ao fechar o form CarroOficina
        private void formclosecarro(object sender, FormClosedEventArgs e)
        {
            AtualizarListaCarro();

        }

        #endregion   #region

        #region "Servicos"

        //não deixar introduzir datas inferiores ao dia de hoje
        private void dateTimePicker1_ValueChanged(object sender, EventArgs e)
        {
            this.dateTimePickerServico.MinDate = DateTime.Today.AddDays(0);
        }

        private void listBoxServico_SelectedIndexChanged(object sender, EventArgs e)
        {
            //sempre que um serviço é selecionado a seleção muda de imediato
            Servico servicoSelecionado = listBoxServico.SelectedItem as Servico;
           
            //verifica se existe algum serviço
            if (listBoxServico.SelectedIndex != -1)
            {

                lbIDServico.Visible = true;
                lbServicoDataEntrada.Visible = true;
                lbServicoTipo.Visible = true;
                lbServicoDataSaida.Visible = true;
                lbServicoTotal.Visible = true;


                lbIDServico.Text = "ID do Serviço:" + servicoSelecionado.IdServico.ToString();
                lbServicoDataEntrada.Text = "Data de Entrada:" + servicoSelecionado.DataEntrada.ToString();
                lbServicoTipo.Text = "Tipo:" + servicoSelecionado.Tipo;
                lbServicoDataSaida.Text = "Data de Saida:" + (servicoSelecionado.DataSaida != null ? Convert.ToString(servicoSelecionado.DataSaida) : "Data de entrega a definir");
                lbServicoTotal.Text = "Valor Total do serviço:" + servicoSelecionado.Total.ToString() + " €";
                AtualizarListaParcela();
            }
          

        }

        private void btnIServico_Click(object sender, EventArgs e)
        {

            //Vai buscar o carro que está selecionado
            CarroOficina carroOficinaSelecionado = listBoxCarro.SelectedItem as CarroOficina;
            //se não existir nenhum carro erro: "Não existe nenhum carro!"
            if (carroOficinaSelecionado == null)
            {
                lbCarroMatricula.Visible = false;
                lbCarroNChassi.Visible = false;
                lbCarroMarca.Visible = false;
                lbCarroModelo.Visible = false;
                lbCarroCombustivel.Visible = false;          
                lbCarroKms.Visible = false;

                MessageBox.Show("Não existe nenhum Carro Selecionado!");
                return;
            }

            //se existir cria um serviço e atualiza a lista 
            Servico servico = new Servico();


            //verificar se dados estão preenchindos 
            if (comboBoxServico.Text == "")
            {
                MessageBox.Show("Não preencheu todos os campos!");
                return;

            }

            if(servico.DataSaida == null)
            {
                servico.DataEntrada = DateTime.Now;
                servico.DataSaida = null;
                servico.Tipo = comboBoxServico.Text;

            }
            else
            {
                servico.DataEntrada = DateTime.Now;
                servico.DataSaida = dateTimePickerServico.Value.Date;
                servico.Tipo = comboBoxServico.Text;
               
            }

            //adiciona um serviço
            carroOficinaSelecionado.Servicos.Add(servico);
            //guarda na base de dados
            basedadosO.SaveChanges();
            MessageBox.Show("Serviço foi inserida com sucesso!");
            //meter os campos limpos
            comboBoxServico.Text = "";
            AtualizarListaServico();

        }

        #endregion

        #region "Parcelas"

        private void btnIParcela_Click(object sender, EventArgs e)
        {

            //pega no valor da txtbox e passar para float
            float valorProduto = 0;

            //verifica se as textboxes não estão vazias
            if (valorTextBox.Text == "" || descricaoTextBox.Text == "")
            {
                MessageBox.Show("Preencha todas as parcelas!");
                return;
            }

            //Vai buscar o serviço que está selecionado
            Servico servisoSelecionado =listBoxServico.SelectedItem as Servico;
            
            //se não existir nenhum serviço. erro: "Não existe nenhum serviço!"eu tenho assim e isso funciona
            if (servisoSelecionado == null)
            {
                MessageBox.Show("Não existe nenhum Serviço selecionado! Caso não tenha nenhum serviço crie.");
                return;
            }


            //se existir cria serviço
            Parcela parcela = new Parcela();

            //CAMPOS
                
                //Valor
                //Variavel para retorno da conversão 
                double valor;
                //Utilização do TryParse, para validação do objeto. Verificamos se o mesmo é double    
                if (double.TryParse(valorTextBox.Text, out valor))
                {
                    parcela.Valor = Convert.ToDouble(valorTextBox.Text);
                    parcela.IncrementarValorTotal(valorProduto);
                }
                else
                {
                    MessageBox.Show("Tem de introduzir os dados corretamentos do campo Valor. Informação:Tem de introduzir numeros.");
                    return;
                }
                
                parcela.Descricao = descricaoTextBox.Text;

            //add parcela à lista
            servisoSelecionado.Parcelas.Add(parcela);
            //salvar na base de dados
            basedadosO.SaveChanges();
            MessageBox.Show("Parcela foi inserida com sucesso!");
            //meter os campos limpos
            valorTextBox.Text = "";
            descricaoTextBox.Text = "";
            //atualiza as listas
            AtualizarListaServico();
            AtualizarListaParcela();
         }
        private void btnEParcela_Click(object sender, EventArgs e)
        {
            Parcela parcelaSelect = listBoxParcela.SelectedItem as Parcela;
            if(parcelaSelect==null)
            {
                MessageBox.Show("Não tem nenhuma selecionada parcela.");
                return;
            }

            if (MessageBox.Show("Eliminar Parcela!", "Deseja eliminar a Parcela?", MessageBoxButtons.YesNo) == DialogResult.Yes)
            {
                try
                {
                    basedadosO.Parcelas.Remove(parcelaSelect);
                    basedadosO.SaveChanges();

                }
                catch (Exception ex)
                {
                    MessageBox.Show("Erro ao eliminar, tente outra vez!", ex.ToString());
                }

                AtualizarListaParcela();
            }
            else
            {
                MessageBox.Show("Este parcela não foi eliminado.");
            }
        }
        #endregion

        #region "Atulizar listas"

        private void AtualizarListaCliente()
        {
            listBoxCliente.DataSource = basedadosO.Clientes.ToList<Cliente>();        
            
        }
        //atualizar a lista dos carros
        private void AtualizarListaCarro()
        {
            Cliente clienteSelecionado = listBoxCliente.SelectedItem as Cliente;
            int pos = listBoxCarro.SelectedIndex; //guardar posição do index
            listBoxCarro.DataSource = null;
            if (clienteSelecionado == null) // se não existir clientes sai
            {
                //bloquear as coisas dos carros
                groupBox2.Enabled = false;

                //ocultar os dados dos carros
                lbCarroMatricula.Visible = false;
                lbCarroNChassi.Visible = false;
                lbCarroMarca.Visible = false;
                lbCarroModelo.Visible = false;
                lbCarroCombustivel.Visible = false;
                lbCarroKms.Visible = false;


            return;
            }
            //desbloquear as coisas dos Carros
            groupBox2.Enabled = true;
            //mostrar os dados dos carros
            lbCarroMatricula.Visible = true;
            lbCarroNChassi.Visible = true;
            lbCarroMarca.Visible = true;
            lbCarroModelo.Visible = true;
            lbCarroCombustivel.Visible = true;
            lbCarroKms.Visible = true;


            listBoxCarro.DataSource = clienteSelecionado.CarrosOficina.ToList(); //atualiza lista
            if (listBoxCarro.Items.Count > 0) //se o numero de elementos da lista for maior que 0
            {
                if (pos < listBoxCarro.Items.Count) //se a posição do index for menor que o numero de elementos na lista
                {
                    listBoxCarro.SelectedIndex = pos; //seleciona a posição               
            }
                else
                {
                    listBoxCarro.SelectedIndex = listBoxCarro.Items.Count - 1; //se não seleciona a posição anterior
                }
            }
            AtualizarListaServico();

        }
        //atualizar a lista dos serviços
        private void AtualizarListaServico()
        {
            CarroOficina carroOficinaSelecionado = listBoxCarro.SelectedItem as CarroOficina;
            int pos = listBoxServico.SelectedIndex; //guardar posição do index
            listBoxServico.DataSource = null;
            if (carroOficinaSelecionado == null) // se não existir clientes sai
            {
                //bloquear as coisas dos servicos
                groupBox3.Enabled = false;

                //ocultar os dados dos carros
                lbCarroMatricula.Visible = false;
                lbCarroNChassi.Visible = false;
                lbCarroMarca.Visible = false;
                lbCarroModelo.Visible = false;
                lbCarroCombustivel.Visible = false;
                lbCarroKms.Visible = false;


            return;
            }
            //desbloquear as coisas dos servicos
            groupBox3.Enabled = true;
            //mostrar os dados dos serviços
            lbIDServico.Visible = true;
            lbServicoDataEntrada.Visible = true;
            lbServicoTipo.Visible = true;
            lbServicoDataSaida.Visible = true;
            lbServicoTotal.Visible = true;

            listBoxServico.DataSource = carroOficinaSelecionado.Servicos.ToList(); //atualiza lista
            if (listBoxServico.Items.Count > 0) //se o numero de elementos da lista for maior que 0
            {
                if (pos < listBoxServico.Items.Count) //se a posição do index for menor que o numero de elementos na lista
                {
                    listBoxServico.SelectedIndex = pos; //sleciona a posição

                }
                else
                {
                    listBoxServico.SelectedIndex = listBoxServico.Items.Count - 1; //se não seleciona a posição anterior
                }
            }
            AtualizarListaParcela();

        }
         //atualizar Lista das Parcelas
        private void AtualizarListaParcela()
        {
            Servico servicoSelecionado = listBoxServico.SelectedItem as Servico;
            int pos = listBoxParcela.SelectedIndex; //guardar posição do index
            listBoxParcela.DataSource = null;
            if (servicoSelecionado == null) // se não existir clientes sai
            {
                //bloquear as coisas das parcelas
                groupBox4.Enabled = false;

                //ocultar os dados dos serviços
                lbIDServico.Visible = false;
                lbServicoDataEntrada.Visible = false;
                lbServicoTipo.Visible = false;
                lbServicoDataSaida.Visible = false;
                lbServicoTotal.Visible = false;

            return;
            }
            //atulizar o valor
           lbServicoTotal.Text = "Valor Total do serviço:" + servicoSelecionado.Total.ToString() + " €";

            //desbloquear as coisas das parcelas
            groupBox4.Enabled = true;

            listBoxParcela.DataSource = servicoSelecionado.Parcelas.ToList(); //atualiza lista

            if (listBoxParcela.Items.Count > 0) //se o numero de elementos da lista for maior que 0
            {
                if (pos < listBoxParcela.Items.Count) //se a posição do index for menor que o numero de elementos na lista
                {
                    listBoxParcela.SelectedIndex = pos; //sleciona a posição
                }
                else
                {
                    listBoxParcela.SelectedIndex = listBoxParcela.Items.Count - 1; //se não seleciona a posição anterior
                }
            }

        }
    #endregion

        //botão sair
        private void sairToolStripMenuItem_Click(object sender, EventArgs e)
        {
            if (MessageBox.Show("Deseja sair da Janela da Oficina?", "Sair!", MessageBoxButtons.YesNo) == DialogResult.Yes)
            {
                basedadosO.Dispose();
                this.Close();
            }
        }
    }     
}