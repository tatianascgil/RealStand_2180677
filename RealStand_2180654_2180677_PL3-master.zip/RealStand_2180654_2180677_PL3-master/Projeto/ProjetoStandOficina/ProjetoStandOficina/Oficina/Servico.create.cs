﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ProjetoStandOficina
{
    public partial class Servico
    {
        
        public double Total
        {
            get
            {
                double total = 0;
                foreach (Parcela item in Parcelas)
                {
                    total += item.Valor;
                }
                return total;

            }
            
        }

        public override string ToString()
        {
            return DataEntrada + Tipo + (DataSaida != null ?  Convert.ToString(DataSaida) :"Data de entrega a definir")+ Total;
        }
    }
}
