﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ProjetoStandOficina
{
    public partial class CarroOficina
    {

        public override string ToString()
        {
            return "Matricula:"+ Matricula +" Nº Chassis:"+ NumeroChassis + " Marca:" + Marca + " Modelo:" + Modelo + 
                " Combustivel:" + Combustivel+ " Kms: " + Kms ;
        }
    }
}
