﻿namespace ProjetoStandOficina
{
    partial class FormOficina
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.Windows.Forms.Label descricaoLabel;
            System.Windows.Forms.Label valorLabel;
            this.listBoxCliente = new System.Windows.Forms.ListBox();
            this.btnICarro = new System.Windows.Forms.Button();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.listBoxCarro = new System.Windows.Forms.ListBox();
            this.listBoxServico = new System.Windows.Forms.ListBox();
            this.listBoxParcela = new System.Windows.Forms.ListBox();
            this.btnIServico = new System.Windows.Forms.Button();
            this.btnIParcela = new System.Windows.Forms.Button();
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.groupBox3 = new System.Windows.Forms.GroupBox();
            this.label2 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.dateTimePickerServico = new System.Windows.Forms.DateTimePicker();
            this.comboBoxServico = new System.Windows.Forms.ComboBox();
            this.groupBox4 = new System.Windows.Forms.GroupBox();
            this.btnEParcela = new System.Windows.Forms.Button();
            this.valorTextBox = new System.Windows.Forms.TextBox();
            this.descricaoTextBox = new System.Windows.Forms.TextBox();
            this.lbClienteNome = new System.Windows.Forms.Label();
            this.clienteBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.lbClienteNif = new System.Windows.Forms.Label();
            this.lbClienteMorada = new System.Windows.Forms.Label();
            this.lbServicoTotal = new System.Windows.Forms.Label();
            this.lbClienteContacto = new System.Windows.Forms.Label();
            this.toolStrip1 = new System.Windows.Forms.ToolStrip();
            this.sairToolStripMenuItem = new System.Windows.Forms.ToolStripLabel();
            this.lbServicoDataSaida = new System.Windows.Forms.Label();
            this.lbCarroMatricula = new System.Windows.Forms.Label();
            this.lbIDServico = new System.Windows.Forms.Label();
            this.lbCarroMarca = new System.Windows.Forms.Label();
            this.lbServicoDataEntrada = new System.Windows.Forms.Label();
            this.lbServicoTipo = new System.Windows.Forms.Label();
            this.lbCarroNChassi = new System.Windows.Forms.Label();
            this.lbCarroModelo = new System.Windows.Forms.Label();
            this.lbCarroCombustivel = new System.Windows.Forms.Label();
            this.lbCarroKms = new System.Windows.Forms.Label();
            this.servicosBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.parcelasBindingSource = new System.Windows.Forms.BindingSource(this.components);
            descricaoLabel = new System.Windows.Forms.Label();
            valorLabel = new System.Windows.Forms.Label();
            this.groupBox1.SuspendLayout();
            this.groupBox2.SuspendLayout();
            this.groupBox3.SuspendLayout();
            this.groupBox4.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.clienteBindingSource)).BeginInit();
            this.toolStrip1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.servicosBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.parcelasBindingSource)).BeginInit();
            this.SuspendLayout();
            // 
            // descricaoLabel
            // 
            descricaoLabel.AutoSize = true;
            descricaoLabel.Location = new System.Drawing.Point(191, 100);
            descricaoLabel.Name = "descricaoLabel";
            descricaoLabel.Size = new System.Drawing.Size(58, 13);
            descricaoLabel.TabIndex = 9;
            descricaoLabel.Text = "Descricao:";
            // 
            // valorLabel
            // 
            valorLabel.AutoSize = true;
            valorLabel.Location = new System.Drawing.Point(191, 177);
            valorLabel.Name = "valorLabel";
            valorLabel.Size = new System.Drawing.Size(34, 13);
            valorLabel.TabIndex = 10;
            valorLabel.Text = "Valor:";
            // 
            // listBoxCliente
            // 
            this.listBoxCliente.FormattingEnabled = true;
            this.listBoxCliente.Location = new System.Drawing.Point(6, 19);
            this.listBoxCliente.Name = "listBoxCliente";
            this.listBoxCliente.Size = new System.Drawing.Size(185, 537);
            this.listBoxCliente.TabIndex = 0;
            this.listBoxCliente.SelectedIndexChanged += new System.EventHandler(this.listBoxCliente_SelectedIndexChanged);
            // 
            // btnICarro
            // 
            this.btnICarro.BackColor = System.Drawing.Color.DarkOrange;
            this.btnICarro.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.btnICarro.Font = new System.Drawing.Font("Microsoft Sans Serif", 8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnICarro.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.btnICarro.Location = new System.Drawing.Point(6, 326);
            this.btnICarro.Name = "btnICarro";
            this.btnICarro.Size = new System.Drawing.Size(157, 24);
            this.btnICarro.TabIndex = 2;
            this.btnICarro.Text = "Inserir Carro";
            this.btnICarro.UseVisualStyleBackColor = false;
            this.btnICarro.Click += new System.EventHandler(this.btnICarro_Click);
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.listBoxCliente);
            this.groupBox1.Location = new System.Drawing.Point(12, 27);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(198, 572);
            this.groupBox1.TabIndex = 4;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "Seleciona um Cliente";
            // 
            // listBoxCarro
            // 
            this.listBoxCarro.FormattingEnabled = true;
            this.listBoxCarro.Location = new System.Drawing.Point(6, 19);
            this.listBoxCarro.Name = "listBoxCarro";
            this.listBoxCarro.Size = new System.Drawing.Size(157, 303);
            this.listBoxCarro.TabIndex = 5;
            this.listBoxCarro.SelectedIndexChanged += new System.EventHandler(this.listBoxCarro_SelectedIndexChanged);
            // 
            // listBoxServico
            // 
            this.listBoxServico.FormattingEnabled = true;
            this.listBoxServico.Location = new System.Drawing.Point(8, 19);
            this.listBoxServico.Name = "listBoxServico";
            this.listBoxServico.Size = new System.Drawing.Size(160, 186);
            this.listBoxServico.TabIndex = 6;
            this.listBoxServico.SelectedIndexChanged += new System.EventHandler(this.listBoxServico_SelectedIndexChanged);
            // 
            // listBoxParcela
            // 
            this.listBoxParcela.FormattingEnabled = true;
            this.listBoxParcela.Location = new System.Drawing.Point(12, 19);
            this.listBoxParcela.Name = "listBoxParcela";
            this.listBoxParcela.Size = new System.Drawing.Size(173, 329);
            this.listBoxParcela.TabIndex = 7;
            // 
            // btnIServico
            // 
            this.btnIServico.BackColor = System.Drawing.Color.DarkOrange;
            this.btnIServico.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.btnIServico.Font = new System.Drawing.Font("Microsoft Sans Serif", 8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnIServico.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.btnIServico.Location = new System.Drawing.Point(6, 326);
            this.btnIServico.Name = "btnIServico";
            this.btnIServico.Size = new System.Drawing.Size(154, 24);
            this.btnIServico.TabIndex = 8;
            this.btnIServico.Text = "Inserir Serviço";
            this.btnIServico.UseVisualStyleBackColor = false;
            this.btnIServico.Click += new System.EventHandler(this.btnIServico_Click);
            // 
            // btnIParcela
            // 
            this.btnIParcela.BackColor = System.Drawing.Color.DarkOrange;
            this.btnIParcela.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.btnIParcela.Font = new System.Drawing.Font("Microsoft Sans Serif", 8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnIParcela.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.btnIParcela.Location = new System.Drawing.Point(191, 286);
            this.btnIParcela.Name = "btnIParcela";
            this.btnIParcela.Size = new System.Drawing.Size(117, 24);
            this.btnIParcela.TabIndex = 9;
            this.btnIParcela.Text = "Inserir Parcela";
            this.btnIParcela.UseVisualStyleBackColor = false;
            this.btnIParcela.Click += new System.EventHandler(this.btnIParcela_Click);
            // 
            // groupBox2
            // 
            this.groupBox2.Controls.Add(this.listBoxCarro);
            this.groupBox2.Controls.Add(this.btnICarro);
            this.groupBox2.Location = new System.Drawing.Point(216, 243);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Size = new System.Drawing.Size(169, 356);
            this.groupBox2.TabIndex = 10;
            this.groupBox2.TabStop = false;
            this.groupBox2.Text = "Carro FormOficina";
            // 
            // groupBox3
            // 
            this.groupBox3.Controls.Add(this.label2);
            this.groupBox3.Controls.Add(this.label1);
            this.groupBox3.Controls.Add(this.dateTimePickerServico);
            this.groupBox3.Controls.Add(this.comboBoxServico);
            this.groupBox3.Controls.Add(this.btnIServico);
            this.groupBox3.Controls.Add(this.listBoxServico);
            this.groupBox3.Location = new System.Drawing.Point(385, 243);
            this.groupBox3.Name = "groupBox3";
            this.groupBox3.Size = new System.Drawing.Size(174, 356);
            this.groupBox3.TabIndex = 11;
            this.groupBox3.TabStop = false;
            this.groupBox3.Text = "Serviço";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(6, 208);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(31, 13);
            this.label2.TabIndex = 14;
            this.label2.Text = "Tipo:";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(6, 269);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(78, 13);
            this.label1.TabIndex = 13;
            this.label1.Text = "Data de Saida:";
            // 
            // dateTimePickerServico
            // 
            this.dateTimePickerServico.CalendarTitleBackColor = System.Drawing.SystemColors.Desktop;
            this.dateTimePickerServico.Location = new System.Drawing.Point(6, 285);
            this.dateTimePickerServico.Name = "dateTimePickerServico";
            this.dateTimePickerServico.Size = new System.Drawing.Size(162, 20);
            this.dateTimePickerServico.TabIndex = 10;
            this.dateTimePickerServico.Value = new System.DateTime(2019, 6, 4, 13, 33, 36, 0);
            this.dateTimePickerServico.ValueChanged += new System.EventHandler(this.dateTimePicker1_ValueChanged);
            // 
            // comboBoxServico
            // 
            this.comboBoxServico.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.comboBoxServico.FormattingEnabled = true;
            this.comboBoxServico.Items.AddRange(new object[] {
            "Arranjo",
            "Manutenção"});
            this.comboBoxServico.Location = new System.Drawing.Point(8, 224);
            this.comboBoxServico.Name = "comboBoxServico";
            this.comboBoxServico.Size = new System.Drawing.Size(154, 21);
            this.comboBoxServico.TabIndex = 9;
            // 
            // groupBox4
            // 
            this.groupBox4.Controls.Add(this.btnEParcela);
            this.groupBox4.Controls.Add(valorLabel);
            this.groupBox4.Controls.Add(this.valorTextBox);
            this.groupBox4.Controls.Add(descricaoLabel);
            this.groupBox4.Controls.Add(this.descricaoTextBox);
            this.groupBox4.Controls.Add(this.listBoxParcela);
            this.groupBox4.Controls.Add(this.btnIParcela);
            this.groupBox4.Location = new System.Drawing.Point(559, 242);
            this.groupBox4.Name = "groupBox4";
            this.groupBox4.Size = new System.Drawing.Size(314, 357);
            this.groupBox4.TabIndex = 12;
            this.groupBox4.TabStop = false;
            this.groupBox4.Text = "Parcelas";
            // 
            // btnEParcela
            // 
            this.btnEParcela.BackColor = System.Drawing.Color.DarkOrange;
            this.btnEParcela.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.btnEParcela.Font = new System.Drawing.Font("Microsoft Sans Serif", 8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnEParcela.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.btnEParcela.Location = new System.Drawing.Point(191, 316);
            this.btnEParcela.Name = "btnEParcela";
            this.btnEParcela.Size = new System.Drawing.Size(117, 24);
            this.btnEParcela.TabIndex = 12;
            this.btnEParcela.Text = "Eliminar Parcela";
            this.btnEParcela.UseVisualStyleBackColor = false;
            this.btnEParcela.Click += new System.EventHandler(this.btnEParcela_Click);
            // 
            // valorTextBox
            // 
            this.valorTextBox.Location = new System.Drawing.Point(194, 193);
            this.valorTextBox.Name = "valorTextBox";
            this.valorTextBox.Size = new System.Drawing.Size(100, 20);
            this.valorTextBox.TabIndex = 11;
            // 
            // descricaoTextBox
            // 
            this.descricaoTextBox.Location = new System.Drawing.Point(191, 116);
            this.descricaoTextBox.Name = "descricaoTextBox";
            this.descricaoTextBox.Size = new System.Drawing.Size(100, 20);
            this.descricaoTextBox.TabIndex = 10;
            // 
            // lbClienteNome
            // 
            this.lbClienteNome.AutoSize = true;
            this.lbClienteNome.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.clienteBindingSource, "Nome", true));
            this.lbClienteNome.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbClienteNome.Location = new System.Drawing.Point(240, 28);
            this.lbClienteNome.Name = "lbClienteNome";
            this.lbClienteNome.Size = new System.Drawing.Size(210, 20);
            this.lbClienteNome.TabIndex = 13;
            this.lbClienteNome.Text = "Sem Cliente Selecionado";
            // 
            // clienteBindingSource
            // 
            this.clienteBindingSource.DataSource = typeof(ProjetoStandOficina.Cliente);
            // 
            // lbClienteNif
            // 
            this.lbClienteNif.AutoSize = true;
            this.lbClienteNif.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.clienteBindingSource, "NIF", true));
            this.lbClienteNif.Location = new System.Drawing.Point(265, 48);
            this.lbClienteNif.Name = "lbClienteNif";
            this.lbClienteNif.Size = new System.Drawing.Size(0, 13);
            this.lbClienteNif.TabIndex = 14;
            // 
            // lbClienteMorada
            // 
            this.lbClienteMorada.AutoSize = true;
            this.lbClienteMorada.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.clienteBindingSource, "Morada", true));
            this.lbClienteMorada.Location = new System.Drawing.Point(265, 64);
            this.lbClienteMorada.Name = "lbClienteMorada";
            this.lbClienteMorada.Size = new System.Drawing.Size(0, 13);
            this.lbClienteMorada.TabIndex = 15;
            // 
            // lbServicoTotal
            // 
            this.lbServicoTotal.AutoSize = true;
            this.lbServicoTotal.Location = new System.Drawing.Point(502, 195);
            this.lbServicoTotal.Name = "lbServicoTotal";
            this.lbServicoTotal.Size = new System.Drawing.Size(0, 13);
            this.lbServicoTotal.TabIndex = 17;
            // 
            // lbClienteContacto
            // 
            this.lbClienteContacto.AutoSize = true;
            this.lbClienteContacto.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.clienteBindingSource, "Contacto", true));
            this.lbClienteContacto.Location = new System.Drawing.Point(265, 81);
            this.lbClienteContacto.Name = "lbClienteContacto";
            this.lbClienteContacto.Size = new System.Drawing.Size(0, 13);
            this.lbClienteContacto.TabIndex = 18;
            // 
            // toolStrip1
            // 
            this.toolStrip1.BackColor = System.Drawing.Color.Transparent;
            this.toolStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.sairToolStripMenuItem});
            this.toolStrip1.Location = new System.Drawing.Point(0, 0);
            this.toolStrip1.Name = "toolStrip1";
            this.toolStrip1.Size = new System.Drawing.Size(884, 25);
            this.toolStrip1.TabIndex = 19;
            this.toolStrip1.Text = "toolStrip1";
            // 
            // sairToolStripMenuItem
            // 
            this.sairToolStripMenuItem.Alignment = System.Windows.Forms.ToolStripItemAlignment.Right;
            this.sairToolStripMenuItem.Name = "sairToolStripMenuItem";
            this.sairToolStripMenuItem.Size = new System.Drawing.Size(26, 22);
            this.sairToolStripMenuItem.Text = "Sair";
            this.sairToolStripMenuItem.Click += new System.EventHandler(this.sairToolStripMenuItem_Click);
            // 
            // lbServicoDataSaida
            // 
            this.lbServicoDataSaida.AutoSize = true;
            this.lbServicoDataSaida.Location = new System.Drawing.Point(502, 180);
            this.lbServicoDataSaida.Name = "lbServicoDataSaida";
            this.lbServicoDataSaida.Size = new System.Drawing.Size(0, 13);
            this.lbServicoDataSaida.TabIndex = 20;
            // 
            // lbCarroMatricula
            // 
            this.lbCarroMatricula.AutoSize = true;
            this.lbCarroMatricula.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.clienteBindingSource, "Nome", true));
            this.lbCarroMatricula.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbCarroMatricula.Location = new System.Drawing.Point(240, 109);
            this.lbCarroMatricula.Name = "lbCarroMatricula";
            this.lbCarroMatricula.Size = new System.Drawing.Size(198, 20);
            this.lbCarroMatricula.TabIndex = 22;
            this.lbCarroMatricula.Text = "Sem Carro Selecionado";
            // 
            // lbIDServico
            // 
            this.lbIDServico.AutoSize = true;
            this.lbIDServico.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.clienteBindingSource, "Nome", true));
            this.lbIDServico.Font = new System.Drawing.Font("Microsoft Sans Serif", 11F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbIDServico.Location = new System.Drawing.Point(477, 130);
            this.lbIDServico.Name = "lbIDServico";
            this.lbIDServico.Size = new System.Drawing.Size(202, 18);
            this.lbIDServico.TabIndex = 23;
            this.lbIDServico.Text = "Sem Serviço Selecionado";
            // 
            // lbCarroMarca
            // 
            this.lbCarroMarca.AutoSize = true;
            this.lbCarroMarca.Location = new System.Drawing.Point(265, 145);
            this.lbCarroMarca.Name = "lbCarroMarca";
            this.lbCarroMarca.Size = new System.Drawing.Size(0, 13);
            this.lbCarroMarca.TabIndex = 24;
            // 
            // lbServicoDataEntrada
            // 
            this.lbServicoDataEntrada.AutoSize = true;
            this.lbServicoDataEntrada.Location = new System.Drawing.Point(502, 150);
            this.lbServicoDataEntrada.Name = "lbServicoDataEntrada";
            this.lbServicoDataEntrada.Size = new System.Drawing.Size(0, 13);
            this.lbServicoDataEntrada.TabIndex = 25;
            // 
            // lbServicoTipo
            // 
            this.lbServicoTipo.AutoSize = true;
            this.lbServicoTipo.Location = new System.Drawing.Point(502, 165);
            this.lbServicoTipo.Name = "lbServicoTipo";
            this.lbServicoTipo.Size = new System.Drawing.Size(0, 13);
            this.lbServicoTipo.TabIndex = 26;
            // 
            // lbCarroNChassi
            // 
            this.lbCarroNChassi.AutoSize = true;
            this.lbCarroNChassi.Location = new System.Drawing.Point(265, 130);
            this.lbCarroNChassi.Name = "lbCarroNChassi";
            this.lbCarroNChassi.Size = new System.Drawing.Size(0, 13);
            this.lbCarroNChassi.TabIndex = 27;
            // 
            // lbCarroModelo
            // 
            this.lbCarroModelo.AutoSize = true;
            this.lbCarroModelo.Location = new System.Drawing.Point(265, 160);
            this.lbCarroModelo.Name = "lbCarroModelo";
            this.lbCarroModelo.Size = new System.Drawing.Size(0, 13);
            this.lbCarroModelo.TabIndex = 28;
            // 
            // lbCarroCombustivel
            // 
            this.lbCarroCombustivel.AutoSize = true;
            this.lbCarroCombustivel.Location = new System.Drawing.Point(265, 175);
            this.lbCarroCombustivel.Name = "lbCarroCombustivel";
            this.lbCarroCombustivel.Size = new System.Drawing.Size(0, 13);
            this.lbCarroCombustivel.TabIndex = 29;
            // 
            // lbCarroKms
            // 
            this.lbCarroKms.AutoSize = true;
            this.lbCarroKms.Location = new System.Drawing.Point(265, 190);
            this.lbCarroKms.Name = "lbCarroKms";
            this.lbCarroKms.Size = new System.Drawing.Size(0, 13);
            this.lbCarroKms.TabIndex = 30;
            // 
            // servicosBindingSource
            // 
            this.servicosBindingSource.DataSource = typeof(ProjetoStandOficina.Servico);
            // 
            // parcelasBindingSource
            // 
            this.parcelasBindingSource.DataSource = typeof(ProjetoStandOficina.Parcela);
            // 
            // FormOficina
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.AutoSize = true;
            this.BackColor = System.Drawing.SystemColors.ControlLightLight;
            this.ClientSize = new System.Drawing.Size(884, 611);
            this.ControlBox = false;
            this.Controls.Add(this.lbCarroKms);
            this.Controls.Add(this.lbCarroCombustivel);
            this.Controls.Add(this.lbCarroModelo);
            this.Controls.Add(this.lbCarroNChassi);
            this.Controls.Add(this.lbServicoTipo);
            this.Controls.Add(this.lbServicoDataEntrada);
            this.Controls.Add(this.lbCarroMarca);
            this.Controls.Add(this.lbIDServico);
            this.Controls.Add(this.lbCarroMatricula);
            this.Controls.Add(this.lbServicoDataSaida);
            this.Controls.Add(this.toolStrip1);
            this.Controls.Add(this.lbClienteContacto);
            this.Controls.Add(this.lbServicoTotal);
            this.Controls.Add(this.lbClienteMorada);
            this.Controls.Add(this.lbClienteNif);
            this.Controls.Add(this.lbClienteNome);
            this.Controls.Add(this.groupBox4);
            this.Controls.Add(this.groupBox3);
            this.Controls.Add(this.groupBox2);
            this.Controls.Add(this.groupBox1);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle;
            this.MaximizeBox = false;
            this.MinimizeBox = false;
            this.Name = "FormOficina";
            this.Text = "Oficina";
            this.Load += new System.EventHandler(this.FormOficina_Load);
            this.groupBox1.ResumeLayout(false);
            this.groupBox2.ResumeLayout(false);
            this.groupBox3.ResumeLayout(false);
            this.groupBox3.PerformLayout();
            this.groupBox4.ResumeLayout(false);
            this.groupBox4.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.clienteBindingSource)).EndInit();
            this.toolStrip1.ResumeLayout(false);
            this.toolStrip1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.servicosBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.parcelasBindingSource)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.ListBox listBoxCliente;
        private System.Windows.Forms.Button btnICarro;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.ListBox listBoxCarro;
        private System.Windows.Forms.ListBox listBoxServico;
        private System.Windows.Forms.ListBox listBoxParcela;
        private System.Windows.Forms.Button btnIServico;
        private System.Windows.Forms.Button btnIParcela;
        private System.Windows.Forms.GroupBox groupBox2;
        private System.Windows.Forms.GroupBox groupBox3;
        private System.Windows.Forms.ComboBox comboBoxServico;
        private System.Windows.Forms.GroupBox groupBox4;
        private System.Windows.Forms.TextBox valorTextBox;
        private System.Windows.Forms.BindingSource parcelasBindingSource;
        private System.Windows.Forms.TextBox descricaoTextBox;
        private System.Windows.Forms.BindingSource servicosBindingSource;
        private System.Windows.Forms.Label lbClienteNome;
        private System.Windows.Forms.Label lbClienteNif;
        private System.Windows.Forms.Label lbClienteMorada;
        private System.Windows.Forms.Label lbServicoTotal;
        private System.Windows.Forms.Label lbClienteContacto;
        private System.Windows.Forms.BindingSource clienteBindingSource;
        private System.Windows.Forms.ToolStrip toolStrip1;
        private System.Windows.Forms.ToolStripLabel sairToolStripMenuItem;
        private System.Windows.Forms.DateTimePicker dateTimePickerServico;
        private System.Windows.Forms.Label lbServicoDataSaida;
        private System.Windows.Forms.Label lbCarroMatricula;
        private System.Windows.Forms.Label lbIDServico;
        private System.Windows.Forms.Label lbCarroMarca;
        private System.Windows.Forms.Label lbServicoDataEntrada;
        private System.Windows.Forms.Label lbServicoTipo;
        private System.Windows.Forms.Label lbCarroNChassi;
        private System.Windows.Forms.Label lbCarroModelo;
        private System.Windows.Forms.Label lbCarroCombustivel;
        private System.Windows.Forms.Label lbCarroKms;
        private System.Windows.Forms.Button btnEParcela;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label1;
    }
}