﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace ProjetoStandOficina
{
    public partial class formCarroOficina : Form
    {
        private BaseDadosOficinaContainer basedadosO;
        private Cliente clienteSelecionado;

        public formCarroOficina(Cliente clienteSelecionado, BaseDadosOficinaContainer basedadosO)
        {
           
            InitializeComponent();
            this.clienteSelecionado= clienteSelecionado;
            this.basedadosO = basedadosO;

            btnSair.Enabled = true;

        }

        

        private void btnICarro_Click(object sender, EventArgs e)
        {
            

            //gera um carro com caratecristicas da oficina novo 
            CarroOficina carroOficina = new CarroOficina();


            if (kmsTextBox.Text == "" || comboBoxCombustivel.Text == "" || marcaTextBox.Text == "" || modeloTextBox.Text =="" || numeroChassisTextBox.Text == "" || maskedTextBoxMatricula.Text == "")
            {
                MessageBox.Show("Preencha todos os campos.");
                return;
            }

            //CAMPOS
            //KMS
            //Variavel para retorno da conversão    
            double kmss;
            //Utilização do TryParse, para validação do objeto. Verificamos se o mesmo é double    
            if (double.TryParse(kmsTextBox.Text, out kmss))
            {
                carroOficina.Kms = Convert.ToDouble(kmsTextBox.Text);
            }
            else
            {
                MessageBox.Show("Tem de introduzir os dados corretamento nos Kms. Informação:Tem de introduzir numeros.");
                return;
            }
            //COMBUSTIVEL, MARCA E MODELO
            carroOficina.Combustivel = comboBoxCombustivel.Text;
            carroOficina.Marca = marcaTextBox.Text;
            carroOficina.Modelo = modeloTextBox.Text;
            //CHASSI E MATRICULA
          
           
            foreach (CarroOficina carroOficinaverificar in basedadosO.Carros.OfType<CarroOficina>())
            {
               /* if (carroOficinaverificar.IdCarro<0) {
                    carroOficina.NumeroChassis = numeroChassisTextBox.Text;
                    carroOficina.Matricula = maskedTextBoxMatricula.Text;
                }
                else {*/
                    if ((carroOficinaverificar.NumeroChassis == Convert.ToString(numeroChassisTextBox.Text)) || (carroOficinaverificar.Matricula == Convert.ToString(maskedTextBoxMatricula.Text)))
                    {
                        MessageBox.Show("Este Carro já foi inserido verifique Nº de Chassi ou a Matricula já existe.");
                        return;
                    }
                    else
                    {
                        carroOficina.NumeroChassis = numeroChassisTextBox.Text;
                        carroOficina.Matricula = maskedTextBoxMatricula.Text;
                    }
                
            }

            //Add o carro oficina
            clienteSelecionado.CarrosOficina.Add(carroOficina);

            //salvar na base de dados o novo carroOficina
            basedadosO.SaveChanges();
            //Menssagem de sucesso
            MessageBox.Show("Carro inscrito com sucesso!","Oficina!");
            this.Close();
            
        }
        //botão sair
        private void btnSair_Click(object sender, EventArgs e)
        {
            if (MessageBox.Show( "Deseja sair sem salvar?", "Sair!", MessageBoxButtons.YesNo) == DialogResult.Yes)
            {
                this.Close();
            }  
            else
            {
                btnSair.Enabled = false;
            }
        }
    }
}
