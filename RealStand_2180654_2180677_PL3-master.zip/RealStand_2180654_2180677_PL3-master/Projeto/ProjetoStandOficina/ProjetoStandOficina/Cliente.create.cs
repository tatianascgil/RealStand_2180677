﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ProjetoStandOficina
{
    public partial class Cliente
    {
        public override string ToString()
        {
            return Nome + "(Nif:" + NIF + ")"+" Morada:"+Morada + " Contacto:"+ Contacto;
        }
    }
}
