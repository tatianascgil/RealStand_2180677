﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ProjetoStandOficina
{
    public partial class Carro
    {

        public override string ToString()
        {
            return "Nº Chassis:" + NumeroChassis + "," + "Marca:" + Marca + "" + " Modelo:" + Modelo + " Combustivel:" + Combustivel;
        }
    }
}
