﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ProjetoStandOficina
{
    public partial class Parcela
    {

        public override string ToString()
        {
            return "Valor:"+Valor+"Descrição:" + Descricao;
        }
    }
}
